# Full user install: copies launcher + RecNet, hardens files, desktop shortcut, DPAPI secrets
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Security

$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallRoot = Join-Path $env:LOCALAPPDATA "FluxRecRoom"
$Desktop = [Environment]::GetFolderPath("Desktop")

function Protect-Secret([string]$plain) {
  if ([string]::IsNullOrEmpty($plain)) { return "" }
  $bytes = [Text.Encoding]::UTF8.GetBytes($plain)
  $p = [Security.Cryptography.ProtectedData]::Protect(
    $bytes, $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
  return [Convert]::ToBase64String($p)
}

Write-Host "Installing to $InstallRoot"

# Optional email for Flux sync
$email = ""
$password = ""
$form = New-Object System.Windows.Forms.Form
$form.Text = "Flux Rec Room Install"
$form.Size = New-Object System.Drawing.Size(440, 260)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false

$l1 = New-Object System.Windows.Forms.Label
$l1.Text = "Flux email (optional - same as website):"
$l1.Location = New-Object System.Drawing.Point(20, 20)
$l1.Size = New-Object System.Drawing.Size(380, 20)
$form.Controls.Add($l1)

$tbEmail = New-Object System.Windows.Forms.TextBox
$tbEmail.Location = New-Object System.Drawing.Point(20, 44)
$tbEmail.Size = New-Object System.Drawing.Size(380, 24)
$form.Controls.Add($tbEmail)

$l2 = New-Object System.Windows.Forms.Label
$l2.Text = "Password (stored encrypted with Windows DPAPI):"
$l2.Location = New-Object System.Drawing.Point(20, 80)
$l2.Size = New-Object System.Drawing.Size(380, 20)
$form.Controls.Add($l2)

$tbPass = New-Object System.Windows.Forms.TextBox
$tbPass.Location = New-Object System.Drawing.Point(20, 104)
$tbPass.Size = New-Object System.Drawing.Size(380, 24)
$tbPass.UseSystemPasswordChar = $true
$form.Controls.Add($tbPass)

$cbSync = New-Object System.Windows.Forms.CheckBox
$cbSync.Text = "Also sync in-game profile photo to Flux avatar"
$cbSync.Location = New-Object System.Drawing.Point(20, 140)
$cbSync.Size = New-Object System.Drawing.Size(380, 24)
$form.Controls.Add($cbSync)

$ok = New-Object System.Windows.Forms.Button
$ok.Text = "Install"
$ok.Location = New-Object System.Drawing.Point(220, 180)
$ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.Controls.Add($ok)
$form.AcceptButton = $ok

$cancel = New-Object System.Windows.Forms.Button
$cancel.Text = "Skip login"
$cancel.Location = New-Object System.Drawing.Point(310, 180)
$cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.Controls.Add($cancel)

$result = $form.ShowDialog()
if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
  $email = $tbEmail.Text.Trim()
  $password = $tbPass.Text
}

New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $InstallRoot "logs") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $InstallRoot "builds\2023") | Out-Null

# Copy launcher + recnet (not multi-GB game; junction if same machine)
$copy = @(
  "FluxLauncher.ps1", "Launch Flux Rec Room.vbs", "builds.json", "version.json",
  "Update-FluxClient.ps1", "Secure-Config.ps1", "Harden-Install.ps1",
  "Verify-Integrity.ps1", "Install-FluxRecRoom.ps1"
)
foreach ($f in $copy) {
  $s = Join-Path $Source $f
  if (Test-Path $s) { Copy-Item $s (Join-Path $InstallRoot $f) -Force }
}

# Copy flux-recnet code (not data dumps if huge - include data structure)
$rnSrc = Join-Path $Source "flux-recnet"
$rnDst = Join-Path $InstallRoot "flux-recnet"
if (Test-Path $rnSrc) {
  New-Item -ItemType Directory -Force -Path $rnDst | Out-Null
  Get-ChildItem $rnSrc -File | ForEach-Object {
    Copy-Item $_.FullName (Join-Path $rnDst $_.Name) -Force
  }
  # copy reborn catalog data
  $dataSrc = Join-Path $rnSrc "data"
  $dataDst = Join-Path $rnDst "data"
  if (Test-Path $dataSrc) {
    New-Item -ItemType Directory -Force -Path $dataDst | Out-Null
    if (Test-Path (Join-Path $dataSrc "reborn")) {
      Copy-Item (Join-Path $dataSrc "reborn") (Join-Path $dataDst "reborn") -Recurse -Force
    }
  }
}

# Junction game client from source (saves disk; user machine only)
$gameSrc = Join-Path $Source "March 19th,2019"
$gameDst = Join-Path $InstallRoot "March 19th,2019"
if ((Test-Path $gameSrc) -and -not (Test-Path $gameDst)) {
  try {
    cmd /c mklink /J "$gameDst" "$gameSrc" | Out-Null
  } catch {
    Write-Host "Could not junction game folder - launcher will use sourceRoot"
  }
}

# 2023 folder placeholder
$r23 = Join-Path $Source "builds\2023\README.md"
if (Test-Path $r23) {
  Copy-Item $r23 (Join-Path $InstallRoot "builds\2023\README.md") -Force
}

# Prefer update URL from running Flux site
$manifestUrl = "http://127.0.0.1:3000/flux-updates/manifest.json"
# After you deploy, change to https://your-app.web.app/flux-updates/manifest.json

$cfg = @{
  buildId             = "2019"
  email               = $email
  passwordEnc         = (Protect-Secret $password)
  syncProfileToFlux   = [bool]$cbSync.Checked
  autoUpdate          = $true
  integrityCheck      = $true
  updateManifestUrl   = $manifestUrl
  sourceRoot          = $Source
  installRoot         = $InstallRoot
}
$cfg | ConvertTo-Json | Set-Content (Join-Path $InstallRoot "launcher-config.json") -Encoding UTF8

# Also keep source launcher-config for dev
$cfg | ConvertTo-Json | Set-Content (Join-Path $Source "launcher-config.json") -Encoding UTF8

# VBS at install root
$vbs = @"
Set sh = CreateObject("Wscript.Shell")
sh.CurrentDirectory = "$($InstallRoot -replace '\\','\\')"
sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""$InstallRoot\FluxLauncher.ps1""", 0, False
"@
$vbsPath = Join-Path $InstallRoot "Launch Flux Rec Room.vbs"
Set-Content $vbsPath $vbs -Encoding ASCII

# Generate integrity then harden
& (Join-Path $Source "publish-update.ps1") -ErrorAction SilentlyContinue
if (Test-Path (Join-Path $Source "integrity.json")) {
  Copy-Item (Join-Path $Source "integrity.json") (Join-Path $InstallRoot "integrity.json") -Force
}
if (Test-Path (Join-Path $InstallRoot "Harden-Install.ps1")) {
  & (Join-Path $InstallRoot "Harden-Install.ps1") -InstallRoot $InstallRoot
}

# Shortcuts point to INSTALLED copy
$wsh = New-Object -ComObject WScript.Shell
$sc = $wsh.CreateShortcut((Join-Path $Desktop "Flux Rec Room.lnk"))
$sc.TargetPath = $vbsPath
$sc.WorkingDirectory = $InstallRoot
$sc.Description = "Flux Rec Room (auto-update, secure)"
$sc.IconLocation = "shell32.dll,137"
$sc.Save()

$sm = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
$sc2 = $wsh.CreateShortcut((Join-Path $sm "Flux Rec Room.lnk"))
$sc2.TargetPath = $vbsPath
$sc2.WorkingDirectory = $InstallRoot
$sc2.Save()

# Dev shortcut in source tree still works
$vbsDev = Join-Path $Source "Launch Flux Rec Room.vbs"
$vbsDevContent = @"
Set sh = CreateObject("Wscript.Shell")
sh.CurrentDirectory = "$($Source -replace '\\','\\')"
sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""$Source\FluxLauncher.ps1""", 0, False
"@
Set-Content $vbsDev $vbsDevContent -Encoding ASCII

[System.Windows.Forms.MessageBox]::Show(
  "Flux Rec Room installed!`n`nLocation: $InstallRoot`nDesktop: Flux Rec Room`n`nFeatures:`n- Silent launch (no CMD)`n- Auto-update when you publish`n- Encrypted Flux password`n- Core files locked read-only`n- Photos sync private to Flux`n`n2023 build: put client files in builds\2023 if you have them.",
  "Flux Rec Room",
  "OK",
  "Information"
) | Out-Null

Write-Host "Installed to $InstallRoot"
