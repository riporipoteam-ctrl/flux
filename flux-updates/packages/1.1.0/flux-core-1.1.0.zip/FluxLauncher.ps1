# Flux Rec Room — silent GUI launcher
# Auto-update + integrity + hidden RecNet + splash + game
$ErrorActionPreference = "SilentlyContinue"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigPath = Join-Path $Root "launcher-config.json"
$RecNet = Join-Path $Root "flux-recnet"
$BuildsJson = Join-Path $Root "builds.json"

# Dot-source helpers
$secure = Join-Path $Root "Secure-Config.ps1"
$update = Join-Path $Root "Update-FluxClient.ps1"
$verify = Join-Path $Root "Verify-Integrity.ps1"
if (Test-Path $secure) { . $secure }

function Read-Json($p) {
  if (-not (Test-Path $p)) { return $null }
  try { return (Get-Content $p -Raw | ConvertFrom-Json) } catch { return $null }
}

# --- Splash ---
$form = New-Object System.Windows.Forms.Form
$form.Text = "Flux Rec Room"
$form.Size = New-Object System.Drawing.Size(500, 340)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "None"
$form.BackColor = [System.Drawing.Color]::FromArgb(12, 14, 22)
$form.TopMost = $true

$grad = New-Object System.Windows.Forms.Panel
$grad.Dock = "Fill"
$grad.BackColor = [System.Drawing.Color]::FromArgb(12, 14, 22)
$form.Controls.Add($grad)

$title = New-Object System.Windows.Forms.Label
$title.Text = "FLUX"
$title.ForeColor = [System.Drawing.Color]::FromArgb(29, 155, 240)
$title.Font = New-Object System.Drawing.Font("Segoe UI", 28, [System.Drawing.FontStyle]::Bold)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(30, 36)
$grad.Controls.Add($title)

$sub = New-Object System.Windows.Forms.Label
$sub.Text = "Rec Room  ·  Secure launcher"
$sub.ForeColor = [System.Drawing.Color]::FromArgb(255, 107, 53)
$sub.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$sub.AutoSize = $true
$sub.Location = New-Object System.Drawing.Point(34, 88)
$grad.Controls.Add($sub)

$status = New-Object System.Windows.Forms.Label
$status.Text = "Starting..."
$status.ForeColor = [System.Drawing.Color]::FromArgb(200, 200, 210)
$status.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$status.AutoSize = $true
$status.Location = New-Object System.Drawing.Point(34, 150)
$grad.Controls.Add($status)

$bar = New-Object System.Windows.Forms.ProgressBar
$bar.Style = "Marquee"
$bar.MarqueeAnimationSpeed = 28
$bar.Location = New-Object System.Drawing.Point(34, 190)
$bar.Size = New-Object System.Drawing.Size(420, 12)
$grad.Controls.Add($bar)

$verLabel = New-Object System.Windows.Forms.Label
$verLabel.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 120)
$verLabel.Font = New-Object System.Drawing.Font("Segoe UI", 8)
$verLabel.AutoSize = $true
$verLabel.Location = New-Object System.Drawing.Point(34, 280)
$grad.Controls.Add($verLabel)

$form.Show()
[System.Windows.Forms.Application]::DoEvents()

function Set-Status($t) {
  $status.Text = $t
  [System.Windows.Forms.Application]::DoEvents()
}

$localVer = "1.0.0"
$vj = Read-Json (Join-Path $Root "version.json")
if ($vj.version) { $localVer = $vj.version }
$verLabel.Text = "v$localVer  ·  no admin  ·  Flux sync"

# --- Config / secrets ---
if (Get-Command Migrate-ConfigSecrets -ErrorAction SilentlyContinue) {
  try { $null = Migrate-ConfigSecrets $ConfigPath } catch {}
}
$cfg = Read-Json $ConfigPath
if (-not $cfg) {
  $cfg = [pscustomobject]@{
    buildId = "2019"
    email = ""
    autoUpdate = $true
    integrityCheck = $true
    updateManifestUrl = "http://127.0.0.1:3000/flux-updates/manifest.json"
  }
}

# --- Auto-update ---
if ($cfg.autoUpdate -ne $false -and (Test-Path $update)) {
  Set-Status "Checking for updates..."
  try {
    $upd = & $update -Root $Root -Silent
    if ($upd -and $upd.updated) {
      Set-Status "Updated to $($upd.version) — restarting launcher..."
      Start-Sleep 1
      $form.Close()
      Start-Process powershell.exe -ArgumentList @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
        "-File", "`"$Root\FluxLauncher.ps1`""
      ) -WindowStyle Hidden
      exit 0
    }
  } catch {
    Set-Status "Update check skipped (offline)"
    Start-Sleep -Milliseconds 600
  }
}

# --- Integrity ---
if ($cfg.integrityCheck -ne $false -and (Test-Path $verify)) {
  Set-Status "Verifying install integrity..."
  try {
    $iv = & $verify -Root $Root
    if ($iv -and $iv.ok -eq $false) {
      Set-Status "WARNING: files were modified — reinstall recommended"
      Start-Sleep 2
    }
  } catch {}
}

$builds = Read-Json $BuildsJson
$buildId = if ($cfg.buildId) { $cfg.buildId } else { "2019" }
$build = $null
if ($builds -and $builds.builds) {
  $build = $builds.builds.$buildId
  if (-not $build) { $build = $builds.builds."2019" }
}

$gameFolder = if ($build) { Join-Path $Root $build.folder } else { Join-Path $Root "March 19th,2019" }
$exeName = if ($build.exe) { $build.exe } else { "Recroom_Release.exe" }
$gameExe = Join-Path $gameFolder $exeName

if (-not (Test-Path $gameExe)) {
  $gameFolder = Join-Path $Root "March 19th,2019"
  $gameExe = Join-Path $gameFolder "Recroom_Release.exe"
}
if (-not (Test-Path $gameExe) -and $buildId -eq "2023") {
  Set-Status "2023 build not installed. Place client in builds\2023\"
  Start-Sleep 4
  $form.Close()
  exit 1
}

# --- RecNet hidden ---
Set-Status "Starting Flux RecNet (background)..."
$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) { $node = "node" }

try {
  Get-NetTCPConnection -LocalPort 2059 -State Listen -ErrorAction SilentlyContinue |
    ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
} catch {}

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $node
$psi.Arguments = "server.mjs"
$psi.WorkingDirectory = $RecNet
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
try {
  [void][System.Diagnostics.Process]::Start($psi)
} catch {
  Set-Status "ERROR: Install Node.js first"
  Start-Sleep 4
  $form.Close()
  exit 1
}

Set-Status "Waiting for server..."
$ok = $false
for ($i = 0; $i -lt 40; $i++) {
  try {
    $r = Invoke-WebRequest "http://127.0.0.1:2059/flux/health" -UseBasicParsing -TimeoutSec 1
    if ($r.StatusCode -eq 200) { $ok = $true; break }
  } catch {}
  Start-Sleep -Milliseconds 250
  [System.Windows.Forms.Application]::DoEvents()
}

if ($ok) { Set-Status "RecNet online · patching..." } else { Set-Status "RecNet slow · launching..." }

try {
  $pp = New-Object System.Diagnostics.ProcessStartInfo
  $pp.FileName = $node
  $pp.Arguments = "patch-client.mjs"
  $pp.WorkingDirectory = $RecNet
  $pp.UseShellExecute = $false
  $pp.CreateNoWindow = $true
  $p2 = [System.Diagnostics.Process]::Start($pp)
  if ($p2) { $p2.WaitForExit(12000) | Out-Null }
} catch {}

# Flux login (encrypted password)
$password = ""
if ($cfg.passwordEnc -and (Get-Command Unprotect-FluxSecret -ErrorAction SilentlyContinue)) {
  $password = Unprotect-FluxSecret $cfg.passwordEnc
} elseif ($cfg.password) {
  $password = [string]$cfg.password
}
if ($cfg.email -and $password) {
  Set-Status "Signing into Flux..."
  try {
    $body = @{ email = $cfg.email; password = $password } | ConvertTo-Json
    Invoke-WebRequest "http://127.0.0.1:2059/flux/login" -Method POST -Body $body `
      -ContentType "application/json" -UseBasicParsing -TimeoutSec 12 | Out-Null
  } catch {}
}

if (-not (Test-Path $gameExe)) {
  Set-Status "ERROR: Game missing: $gameExe"
  Start-Sleep 5
  $form.Close()
  exit 1
}

try { Set-Content (Join-Path $gameFolder "steam_appid.txt") "471710" -NoNewline } catch {}

$buildName = if ($build.name) { $build.name } else { "Rec Room" }
Set-Status "Launching $buildName..."
$env:SteamAppId = "471710"
$env:SteamGameId = "471710"

$gpsi = New-Object System.Diagnostics.ProcessStartInfo
$gpsi.FileName = $gameExe
$gpsi.WorkingDirectory = $gameFolder
$gpsi.UseShellExecute = $false
$gpsi.CreateNoWindow = $true
$gpsi.Arguments = "-screen-fullscreen 0 -screen-width 1920 -screen-height 1080 -force-d3d11"
try {
  [void][System.Diagnostics.Process]::Start($gpsi)
} catch {
  Start-Process -FilePath $gameExe -WorkingDirectory $gameFolder
}

Set-Status "Ready · have fun"
Start-Sleep 2
$form.Close()
[System.Windows.Forms.Application]::Exit()
