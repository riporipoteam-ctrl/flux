# Auto-update for Flux Rec Room launcher + RecNet (not multi-GB game client)
# Checks remote manifest (Firebase Hosting / your site), verifies SHA256, applies zip.
param(
  [string]$Root = "",
  [string]$ManifestUrl = "",
  [switch]$Silent
)

$ErrorActionPreference = "Stop"
if (-not $Root) { $Root = Split-Path -Parent $MyInvocation.MyCommand.Path }

function Write-Log($msg) {
  $log = Join-Path $Root "logs\update.log"
  $dir = Split-Path $log
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  $line = "$(Get-Date -Format o) $msg"
  Add-Content -Path $log -Value $line -Encoding UTF8
  if (-not $Silent) { Write-Host $msg }
}

function Get-FileSha256($path) {
  if (-not (Test-Path $path)) { return $null }
  return (Get-FileHash -Path $path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Compare-Version([string]$a, [string]$b) {
  # returns 1 if a>b, 0 equal, -1 if a<b
  $pa = $a.Split('.') | ForEach-Object { [int]$_ }
  $pb = $b.Split('.') | ForEach-Object { [int]$_ }
  $len = [Math]::Max($pa.Count, $pb.Count)
  for ($i = 0; $i -lt $len; $i++) {
    $x = if ($i -lt $pa.Count) { $pa[$i] } else { 0 }
    $y = if ($i -lt $pb.Count) { $pb[$i] } else { 0 }
    if ($x -gt $y) { return 1 }
    if ($x -lt $y) { return -1 }
  }
  return 0
}

$localVersionPath = Join-Path $Root "version.json"
$local = @{ version = "0.0.0" }
if (Test-Path $localVersionPath) {
  try { $local = Get-Content $localVersionPath -Raw | ConvertFrom-Json } catch {}
}

# Resolve update URL: config > env > default relative to Flux site
$cfgPath = Join-Path $Root "launcher-config.json"
$cfg = $null
if (Test-Path $cfgPath) {
  try { $cfg = Get-Content $cfgPath -Raw | ConvertFrom-Json } catch {}
}

if (-not $ManifestUrl) {
  $ManifestUrl = $cfg.updateManifestUrl
}
if (-not $ManifestUrl) {
  $ManifestUrl = $env:FLUX_UPDATE_MANIFEST_URL
}
if (-not $ManifestUrl) {
  # Default: your Flux site (change after deploy)
  $ManifestUrl = "https://localhost:3000/flux-updates/manifest.json"
}

Write-Log "Checking updates: $ManifestUrl (local $($local.version))"

try {
  $manifest = Invoke-RestMethod -Uri $ManifestUrl -TimeoutSec 12 -UserAgent "FluxLauncher/$($local.version)"
} catch {
  Write-Log "Update check failed (offline or bad URL): $($_.Exception.Message)"
  return @{ updated = $false; reason = "offline" }
}

$remoteVer = [string]$manifest.version
if (-not $remoteVer) {
  Write-Log "Manifest missing version"
  return @{ updated = $false; reason = "bad-manifest" }
}

if ((Compare-Version $remoteVer $local.version) -le 0) {
  Write-Log "Already up to date ($($local.version))"
  return @{ updated = $false; reason = "current"; version = $local.version }
}

Write-Log "Update available: $($local.version) -> $remoteVer"

$pkg = $manifest.packages | Select-Object -First 1
if (-not $pkg) {
  Write-Log "No packages in manifest"
  return @{ updated = $false; reason = "no-package" }
}

$baseUrl = $manifest.baseUrl
if ($baseUrl -and -not $baseUrl.StartsWith("http")) {
  # relative to site origin of manifest
  $origin = ([Uri]$ManifestUrl).GetLeftPart([UriPartial]::Authority)
  if ($baseUrl.StartsWith("/")) {
    $baseUrl = $origin + $baseUrl
  } else {
    $baseUrl = $origin.TrimEnd('/') + '/' + $baseUrl.TrimStart('/')
  }
}
$zipUrl = if ($pkg.url) { $pkg.url } else { ($baseUrl.TrimEnd('/') + '/' + $pkg.path) }
$expectedHash = ([string]$pkg.sha256).ToLowerInvariant()

$tmp = Join-Path $env:TEMP "flux-update-$(Get-Random)"
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
$zipPath = Join-Path $tmp "update.zip"

try {
  Write-Log "Downloading $zipUrl"
  Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing -UserAgent "FluxLauncher/$($local.version)"
  $hash = Get-FileSha256 $zipPath
  if ($expectedHash -and $expectedHash -notmatch 'GENERATE' -and $hash -ne $expectedHash) {
    throw "SHA256 mismatch: got $hash expected $expectedHash"
  }
  Write-Log "Hash OK: $hash"

  $extract = Join-Path $tmp "extract"
  Expand-Archive -Path $zipPath -DestinationPath $extract -Force

  # Apply files under Root (never overwrite user secrets)
  $skip = @("launcher-config.json", "data", "logs", "builds\2023")
  Get-ChildItem $extract -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring($extract.Length).TrimStart('\', '/')
    $blocked = $false
    foreach ($s in $skip) {
      if ($rel -like "$s*" -or $rel -eq $s) { $blocked = $true }
    }
    if ($blocked) { return }
    $dest = Join-Path $Root $rel
    $destDir = Split-Path $dest
    if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Force -Path $destDir | Out-Null }
    # If install is read-only, temporarily allow write for update
    try {
      Copy-Item $_.FullName $dest -Force
    } catch {
      Write-Log "Could not write $rel : $($_.Exception.Message)"
    }
  }

  # Write new version
  @{
    version     = $remoteVer
    channel     = $manifest.channel
    updatedAt   = (Get-Date).ToString("o")
    fromManifest = $ManifestUrl
  } | ConvertTo-Json | Set-Content (Join-Path $Root "version.json") -Encoding UTF8

  Write-Log "Update applied to $remoteVer"
  return @{ updated = $true; version = $remoteVer }
} catch {
  Write-Log "Update failed: $($_.Exception.Message)"
  return @{ updated = $false; reason = "error"; error = $_.Exception.Message }
} finally {
  try { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue } catch {}
}
