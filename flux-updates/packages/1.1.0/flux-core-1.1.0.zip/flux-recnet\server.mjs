/**
 * Flux RecNet — private Rec Room name/API server (built for Flux).
 * Emulates enough of RecNet for March 2019 Recroom_Release client boot + local play.
 * Port: 2059 (client patched to http://127.0.0.1:2059/2)
 *
 * Critical paths:
 *  - NameServer /2
 *  - platformlogin createaccount / loginaccount / getcachedlogins
 *  - SignalR Core hub/v1 (post-login "code: note" was failing here)
 *  - presence heartbeat
 */
import http from "http";
import crypto from "crypto";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import {
  getRoomDetails,
  listRooms,
  listHotRooms,
  roomFilters,
  resolveRoomName,
  ROOM_CATALOG,
} from "./rooms-catalog.mjs";
import {
  getAvatarItems,
  getEquipmentUnlocked,
  getConsumablesUnlocked,
  buildStorefrontCatalog,
  currencyBalances,
  slideshowPayload,
  rebornGameConfigs,
} from "./catalog-data.mjs";
import * as accounts from "./accounts-store.mjs";
import {
  getNamedImage,
  saveProfileUpload,
  defaultTinyPng,
} from "./image-store.mjs";
import * as fluxFb from "./flux-firebase-bridge.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.FLUX_RECNET_PORT || 2059);
const HOST = process.env.FLUX_RECNET_HOST || "127.0.0.1";
const DATA = path.join(__dirname, "data");
const LOG = path.join(DATA, "requests.log");
const BASE = `http://${HOST}:${PORT}`;

// SignalR Core record separator
const RS = "\x1e";

/** @type {Map<string, { id: string, created: number, handshakeDone: boolean, messages: string[] }>} */
const hubConnections = new Map();

function loadProfile() {
  const a = accounts.getActive();
  return {
    playerId: a.playerId,
    username: a.username,
    displayName: a.displayName,
    level: a.level ?? 50,
    xp: a.xp ?? 99999,
    token: a.token || "flux-local-token",
  };
}

/** Live view of active account (re-read each time accounts change) */
function getProfile() {
  return loadProfile();
}

let session = null;

function saveProfile() {
  /* accounts-store owns persistence */
}

function playerObject(platformId = "1", platform = 0, acc = null) {
  return accounts.playerObjectFrom(acc || accounts.getActive(), platformId, platform);
}

function nameServerPayload() {
  return {
    API: BASE,
    Accounts: BASE,
    Rooms: BASE,
    Matchmaking: BASE,
    Notifications: BASE,
    Images: BASE,
    Commerce: BASE,
    RoomStorage: BASE,
    Storage: BASE,
    Leaderboards: BASE,
  };
}

function configV2() {
  const levels = [];
  for (let i = 0; i <= 20; i++) {
    levels.push({ Level: i, RequiredXp: i === 0 ? 1 : i + 1 });
  }
  const day = [
    { type: 20, score: 1 },
    { type: 21, score: 1 },
    { type: 22, score: 1 },
  ];
  // CRITICAL: AutoMicMutingConfig must be non-null.
  // MicSpamMonitor..ctor(null) → NRE → "Error initializing Core Systems" → black screen.
  const autoMic = {
    MicSpamVolumeThreshold: 0.5,
    MicVolumeSampleInterval: 0.1,
    MicVolumeSampleRollingWindowLength: 50,
    MicSpamSamplePercentageForWarning: 0.8,
    MicSpamSamplePercentageForWarningToEnd: 0.5,
    MicSpamSamplePercentageForForceMute: 0.95,
    MicSpamSamplePercentageForForceMuteToEnd: 0.6,
    MicSpamWarningStateVolumeMultiplier: 0.25,
  };
  return {
    MessageOfTheDay: "Welcome to Flux RecNet - private Rec Room!",
    CdnBaseUri: `${BASE}/`,
    LevelProgressionMaps: levels,
    // Some deserializers also read singular LevelProgressionMap
    LevelProgressionMap: levels,
    MatchmakingParams: {
      PreferFullRoomsFrequency: 1.0,
      PreferEmptyRoomsFrequency: 0.0,
    },
    DailyObjectives: [day, day, day, day, day, day, day],
    ServerMaintenance: null,
    AutoMicMutingConfig: autoMic,
    ConfigTable: [
      { Key: "Gift.DropChance", Value: "0.5" },
      { Key: "Gift.XP", Value: "0.5" },
      { Key: "forceRegistration", Value: "0" },
      { Key: "Screens.ForceVerification", Value: "0" },
      { Key: "SkipProfileSelection", Value: "0" },
      { Key: "SkipRegistrationVideo", Value: "1" },
      { Key: "StayInSplashScreen", Value: "0" },
    ],
    PhotonConfig: {
      CloudRegion: "us",
      CrcCheckEnabled: false,
      EnableServerTracingAfterDisconnect: false,
    },
  };
}

function dormRoomDetails() {
  return getRoomDetails("DormRoom", getProfile().playerId);
}

function gameSession(opts = {}) {
  const rawName = opts.RoomName || opts.roomName || "DormRoom";
  const resolved = resolveRoomName(rawName);
  const isPrivate = !!(opts.Private ?? opts.private);
  const roomDetails = getRoomDetails(resolved, getProfile().playerId);

  // Optional scene pick by name
  let scene = roomDetails.Scenes[0];
  const wantScene = opts.SceneName || opts.sceneName;
  if (wantScene) {
    const hit = roomDetails.Scenes.find(
      (s) => String(s.Name).toLowerCase() === String(wantScene).toLowerCase()
    );
    if (hit) scene = hit;
  }

  const isDorm = !!roomDetails.Room.IsDormRoom;
  const photonRoomId =
    String(roomDetails.Room.RoomId) +
    "-" +
    String(getProfile().playerId) +
    (isPrivate ? "-p" : "");

  session = {
    GameSessionId: Date.now() % 1e12 || 20181,
    PhotonRegionId: "us",
    PhotonRoomId: photonRoomId,
    Name: roomDetails.Room.Name,
    RoomId: roomDetails.Room.RoomId,
    RoomSceneId: scene.RoomSceneId,
    RoomSceneLocationId: scene.RoomSceneLocationId,
    IsSandbox: scene.IsSandbox,
    DataBlobName: scene.DataBlobName || "",
    PlayerEventId: null,
    Private: isPrivate,
    GameInProgress: false,
    MaxCapacity: roomDetails.Room.MaxPlayers || 20,
    IsFull: false,
    RegionId: "us",
    RecRoomId: null,
    EventId: null,
    CreatorPlayerId: getProfile().playerId,
    ActivityLevelId: isDorm ? "dormroom" : roomDetails.Room.Name,
    SupportsScreens: true,
    SupportsVR: true,
    Sandbox: scene.IsSandbox,
  };
  return { session, roomDetails };
}

function joinRoomResult(body) {
  const j = parseBody(body || "{}");
  const { session: gs, roomDetails } = gameSession({
    RoomName: j.RoomName || j.roomName || "DormRoom",
    SceneName: j.SceneName || j.sceneName,
    Private: j.Private ?? j.private ?? false,
  });
  console.log(
    `[FluxRecNet] JOIN ${roomDetails.Room.Name} scene=${gs.RoomSceneLocationId} photon=${gs.PhotonRoomId}`
  );
  return {
    Result: 0,
    GameSession: gs,
    RoomDetails: roomDetails,
  };
}

/**
 * RecNet.PlayerPresence — 2019 fields (KeyNotFound if any required key missing):
 * PlayerId, IsOnline, PlayerType, StatusVisibility, InScreenMode, GameSession
 * Nested GameSession uses the Vault 2018/2019 shape (or null if not in a room).
 */
function presenceGameSession() {
  // Prefer live session; otherwise a stable dorm session so UpdateLocalGameSession has data
  if (session) return session;
  return gameSession({ RoomName: "DormRoom", Private: true }).session;
}

function presenceStatus() {
  return {
    PlayerId: getProfile().playerId,
    IsOnline: true,
    InScreenMode: true,
    PlayerType: 3, // Screen mode (client posts PlayerType:3 on setplayertype)
    StatusVisibility: 0, // REQUIRED — missing this broke presence → core systems cascade
    DeviceClass: 0,
    GameSession: presenceGameSession(),
  };
}

function communityBoardPayload() {
  // communityboard/v1/current — NOT FeaturedRooms (that's rooms/v1/featuredRoomGroup).
  // Shape from metadata: Announcement / SourceUrl / videos
  return {
    Announcement: null,
    CurrentAnnouncement: null,
    SourceUrl: null,
    Videos: [],
    videos: [],
  };
}

function featuredRoomGroupPayload() {
  // rooms/v1/featuredRoomGroup — use real catalog ImageNames (colored thumbs)
  const rooms = listRooms()
    .filter((r) => !r.IsDormRoom)
    .slice(0, 16)
    .map((r) => ({
      RoomName: r.Name,
      RoomId: r.RoomId,
      ImageName: r.ImageName || "DefaultRoomImage.jpg",
    }));
  return {
    Name: "Flux Rec Room Originals",
    FeaturedRooms: rooms.length
      ? rooms
      : [
          { RoomName: "RecCenter", RoomId: 2, ImageName: "22eefa3219f046fd9e2090814650ede3" },
          { RoomName: "GoldenTrophy", RoomId: 13, ImageName: "38e9d0d4eff94556a0b106508249dcf9" },
          { RoomName: "Paintball", RoomId: 8, ImageName: "93a53ced93a04f658795a87f4a4aab85" },
        ],
  };
}

function loadingScreenTipPayload() {
  // /config/LoadingScreenTipData — root is LIST of LoadingScreenTip objects
  // Required keys: HasImage, Image, RoomNames (KeyNotFound if missing)
  // for this path the tip list shape is required.
  return [
    {
      HasImage: false,
      Image: null,
      RoomNames: [],
      Tip: "Welcome to Flux private RecNet!",
    },
  ];
}

function heartbeatResponse() {
  // HeartbeatResponse has .Presence (not a bare PlayerPresence)
  return {
    Presence: presenceStatus(),
  };
}

function parseBody(raw) {
  if (raw == null) return {};
  if (Buffer.isBuffer(raw) && raw.length === 0) return {};
  // Binary uploads (images) — don't try to parse as form/json
  if (Buffer.isBuffer(raw) && raw.length > 0 && raw[0] === 0x89 /* PNG */) return {};
  if (Buffer.isBuffer(raw) && raw.length > 1 && raw[0] === 0xff && raw[1] === 0xd8) return {};
  const s = bodyAsString(raw).trim();
  if (!s) return {};
  if (s.startsWith("{") || s.startsWith("[")) {
    try {
      return JSON.parse(s);
    } catch {
      /* fall through */
    }
  }
  const out = {};
  for (const part of s.split("&")) {
    if (!part) continue;
    const eq = part.indexOf("=");
    const k = decodeURIComponent((eq >= 0 ? part.slice(0, eq) : part).replace(/\+/g, " "));
    const v = decodeURIComponent((eq >= 0 ? part.slice(eq + 1) : "").replace(/\+/g, " "));
    out[k] = v;
  }
  return out;
}

function parsePlatformId(body) {
  const rawStr = bodyAsString(body);
  const m = rawStr.match(/PlatformId=(\d+)/i);
  if (m) return m[1];

  const j =
    Buffer.isBuffer(body) || typeof body === "string"
      ? parseBody(body)
      : typeof body === "object" && body && !Array.isArray(body)
        ? body
        : parseBody(body);
  const raw =
    j.PlatformId ??
    j.platformId ??
    j.PlatformID ??
    j.platformID ??
    (Array.isArray(j.PlatformIds) ? j.PlatformIds[0]?.PlatformId : null);
  if (raw === undefined || raw === null || raw === "") return "1";
  return String(raw);
}

function parsePlatform(body) {
  const j =
    typeof body === "object" && body && !Array.isArray(body) ? body : parseBody(body);
  const raw = j.Platform ?? j.platform ?? 0;
  const n = Number(raw);
  return Number.isFinite(n) ? n : 0;
}

/**
 * JSON with PlatformId as raw number (Steam IDs exceed JS safe integers).
 */
function toJson(data) {
  const s = JSON.stringify(data);
  // "PlatformId":"7656..." → "PlatformId":7656...
  return s.replace(/"PlatformId":"(\d+)"/g, '"PlatformId":$1');
}

function loginCached(platformId = "1", platform = 0) {
  // Error: null (not "") — client treats non-null Error as failure
  return {
    Error: null,
    Player: playerObject(platformId, platform),
    Token: getProfile().token || "flux-local-token",
    FirstLoginOfTheDay: true,
    AnalyticsSessionId: Date.now() % 1e12,
    CanUseScreenMode: true,
  };
}

function logReq(method, url, status, bodyPreview) {
  const line = `${new Date().toISOString()} ${method} ${url} → ${status} ${bodyPreview || ""}\n`;
  try {
    fs.appendFileSync(LOG, line);
  } catch {
    /* ignore */
  }
  console.log(`[FluxRecNet] ${method} ${url} → ${status}`);
}

function send(res, status, data, contentType = "application/json") {
  let body;
  if (typeof data === "string" || Buffer.isBuffer(data)) {
    body = data;
  } else {
    body = toJson(data);
  }
  const buf = Buffer.isBuffer(body) ? body : Buffer.from(body, "utf8");
  res.writeHead(status, {
    "Content-Type": contentType,
    "Content-Length": buf.length,
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "*",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  });
  res.end(buf);
}

function stripApi(pathname) {
  let p = pathname || "/";
  if (p.startsWith("/api/")) p = p.slice(5);
  else if (p.startsWith("/api")) p = p.slice(4);
  if (p.startsWith("/")) p = p.slice(1);
  return p;
}

async function readBody(req) {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  // Keep raw Buffer so profile image uploads aren't corrupted
  return Buffer.concat(chunks);
}

function bodyAsString(body) {
  if (Buffer.isBuffer(body)) return body.toString("utf8");
  if (body == null) return "";
  return String(body);
}

function newHubConnection() {
  const id = crypto.randomBytes(16).toString("hex");
  const conn = {
    id,
    created: Date.now(),
    handshakeDone: false,
    messages: [],
  };
  hubConnections.set(id, conn);
  // GC old connections
  for (const [k, v] of hubConnections) {
    if (Date.now() - v.created > 30 * 60 * 1000) hubConnections.delete(k);
  }
  return conn;
}

function negotiatePayload() {
  const conn = newHubConnection();
  // Prefer LongPolling first — more reliable than our raw WS for BestHTTP SignalR Core
  return {
    negotiateVersion: 1,
    connectionId: conn.id,
    connectionToken: conn.id,
    availableTransports: [
      {
        transport: "LongPolling",
        transferFormats: ["Text", "Binary"],
      },
      {
        transport: "WebSockets",
        transferFormats: ["Text", "Binary"],
      },
      {
        transport: "ServerSentEvents",
        transferFormats: ["Text"],
      },
    ],
  };
}

// --- Minimal WebSocket (server → client unmasked frames) ---
function wsAcceptKey(key) {
  return crypto
    .createHash("sha1")
    .update(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")
    .digest("base64");
}

function wsEncodeText(str) {
  const payload = Buffer.from(str, "utf8");
  const len = payload.length;
  let header;
  if (len < 126) {
    header = Buffer.alloc(2);
    header[0] = 0x81; // FIN + text
    header[1] = len;
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x81;
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x81;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, payload]);
}

function wsEncodeClose(code = 1000) {
  const payload = Buffer.alloc(2);
  payload.writeUInt16BE(code, 0);
  const header = Buffer.alloc(2);
  header[0] = 0x88; // FIN + close
  header[1] = 2;
  return Buffer.concat([header, payload]);
}

function wsEncodePong(data) {
  const payload = data && data.length ? data : Buffer.alloc(0);
  const header = Buffer.alloc(2);
  header[0] = 0x8a; // FIN + pong
  header[1] = payload.length;
  return Buffer.concat([header, payload]);
}

function wsDecodeFrames(buf) {
  const messages = [];
  let offset = 0;
  while (offset + 2 <= buf.length) {
    const start = offset;
    const b0 = buf[offset];
    const b1 = buf[offset + 1];
    const opcode = b0 & 0x0f;
    const masked = (b1 & 0x80) !== 0;
    let len = b1 & 0x7f;
    offset += 2;
    if (len === 126) {
      if (offset + 2 > buf.length) return { messages, rest: buf.slice(start) };
      len = buf.readUInt16BE(offset);
      offset += 2;
    } else if (len === 127) {
      if (offset + 8 > buf.length) return { messages, rest: buf.slice(start) };
      len = Number(buf.readBigUInt64BE(offset));
      offset += 8;
    }
    let mask;
    if (masked) {
      if (offset + 4 > buf.length) return { messages, rest: buf.slice(start) };
      mask = buf.slice(offset, offset + 4);
      offset += 4;
    }
    if (offset + len > buf.length) return { messages, rest: buf.slice(start) };
    let payload = buf.slice(offset, offset + len);
    offset += len;
    if (masked && mask) {
      const out = Buffer.alloc(payload.length);
      for (let i = 0; i < payload.length; i++) out[i] = payload[i] ^ mask[i % 4];
      payload = out;
    }
    if (opcode === 0x8) {
      messages.push({ type: "close", data: payload });
    } else if (opcode === 0x9) {
      messages.push({ type: "ping", data: payload });
    } else if (opcode === 0xa) {
      messages.push({ type: "pong", data: payload });
    } else if (opcode === 0x1 || opcode === 0x2 || opcode === 0x0) {
      messages.push({ type: "data", data: payload.toString("utf8") });
    }
  }
  return { messages, rest: buf.slice(offset) };
}

/** Process SignalR JSON messages (handshake / ping / invoke) */
function processSignalRMessages(conn, text, sendText) {
  const parts = String(text || "")
    .split(RS)
    .filter((p) => p.length > 0);
  for (const part of parts) {
    try {
      const j = JSON.parse(part);
      // Handshake request
      if (j.protocol != null) {
        conn.handshakeDone = true;
        sendText("{}" + RS);
        logReq("HUB", `handshake ${conn.id}`, 200, String(j.protocol));
        continue;
      }
      // SignalR ping (type 6) → pong (type 6)
      if (j.type === 6) {
        sendText(JSON.stringify({ type: 6 }) + RS);
        continue;
      }
      // Close (type 7)
      if (j.type === 7) {
        sendText(JSON.stringify({ type: 7 }) + RS);
        continue;
      }
      // Invocation (type 1) — optional Completion (type 3)
      if (j.type === 1 && j.invocationId != null) {
        sendText(
          JSON.stringify({
            type: 3,
            invocationId: j.invocationId,
            result: null,
          }) + RS
        );
        continue;
      }
      // Stream item / cancel / other — ignore safely
    } catch {
      // Non-JSON: older OpenRec hub echo
      if (part && !conn.handshakeDone) {
        conn.handshakeDone = true;
        sendText("{}" + RS);
      }
    }
  }
}

function handleWsHub(req, socket, head, connectionId) {
  const key = req.headers["sec-websocket-key"];
  if (!key) {
    try {
      socket.destroy();
    } catch {
      /* ignore */
    }
    return;
  }

  try {
    socket.setTimeout(0);
    socket.setNoDelay(true);
    socket.setKeepAlive(true, 10000);
  } catch {
    /* ignore */
  }

  const accept = wsAcceptKey(key);
  const proto = req.headers["sec-websocket-protocol"];
  let protoLine = "";
  if (proto) {
    // echo first requested subprotocol if any
    const first = String(proto).split(",")[0].trim();
    if (first) protoLine = `Sec-WebSocket-Protocol: ${first}\r\n`;
  }

  socket.write(
    "HTTP/1.1 101 Switching Protocols\r\n" +
      "Upgrade: websocket\r\n" +
      "Connection: Upgrade\r\n" +
      `Sec-WebSocket-Accept: ${accept}\r\n` +
      protoLine +
      "\r\n"
  );

  let conn = hubConnections.get(connectionId);
  if (!conn) {
    conn = {
      id: connectionId,
      created: Date.now(),
      handshakeDone: false,
      messages: [],
      socket,
    };
    hubConnections.set(connectionId, conn);
  } else {
    conn.socket = socket;
  }

  logReq("WS", `/hub/v1?id=${connectionId}`, 101, "upgrade");

  const sendText = (str) => {
    try {
      if (socket.writable) socket.write(wsEncodeText(str));
    } catch {
      /* ignore */
    }
  };

  // IMPORTANT: `head` is leftover client bytes — process as frames, NEVER echo back
  let buffer = head && head.length ? Buffer.from(head) : Buffer.alloc(0);

  const handleIncoming = () => {
    const { messages, rest } = wsDecodeFrames(buffer);
    buffer = rest;
    for (const msg of messages) {
      if (msg.type === "close") {
        clearInterval(pingTimer);
        try {
          if (socket.writable) socket.write(wsEncodeClose(1000));
          socket.end();
        } catch {
          /* ignore */
        }
        return;
      }
      if (msg.type === "ping") {
        try {
          if (socket.writable) socket.write(wsEncodePong(msg.data));
        } catch {
          /* ignore */
        }
        continue;
      }
      if (msg.type === "data") {
        processSignalRMessages(conn, msg.data, sendText);
      }
    }
  };

  // Process any bytes that arrived with the upgrade
  if (buffer.length) handleIncoming();

  const pingTimer = setInterval(() => {
    if (!socket.writable) {
      clearInterval(pingTimer);
      return;
    }
    try {
      // Keep-alive SignalR ping
      sendText(JSON.stringify({ type: 6 }) + RS);
    } catch {
      clearInterval(pingTimer);
    }
  }, 10000);

  socket.on("data", (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    handleIncoming();
  });

  socket.on("error", (e) => {
    console.log("[FluxRecNet] WS error", connectionId, e.message);
    clearInterval(pingTimer);
  });
  socket.on("close", () => {
    clearInterval(pingTimer);
    if (conn.socket === socket) conn.socket = null;
    logReq("WS", `/hub/v1 close`, 200, connectionId);
  });
}

/**
 * Long-polling / SSE transport for SignalR Core hub/v1
 */
async function handleHubHttp(method, pathname, url, body, res) {
  const u = url;
  const id =
    u.searchParams.get("id") ||
    u.searchParams.get("connectionId") ||
    u.searchParams.get("connectionToken") ||
    "";

  // negotiate
  if (pathname.toLowerCase().includes("negotiate")) {
    const payload = negotiatePayload();
    logReq(method, pathname, 200, `negotiate ${payload.connectionId}`);
    send(res, 200, payload);
    return true;
  }

  // long poll GET — hold for messages (handshake ack may be queued here)
  if (method === "GET") {
    let conn = hubConnections.get(id);
    if (!conn) {
      conn = {
        id: id || "anon",
        created: Date.now(),
        handshakeDone: false,
        messages: [],
      };
      if (id) hubConnections.set(id, conn);
    }
    const start = Date.now();
    while (Date.now() - start < 15000 && conn.messages.length === 0) {
      await new Promise((r) => setTimeout(r, 50));
      if (res.socket && res.socket.destroyed) return true;
    }
    if (conn.messages.length) {
      const out = conn.messages.splice(0, conn.messages.length).join("");
      logReq(method, pathname + (id ? `?id=${id}` : ""), 200, "poll msgs");
      // SignalR long polling returns text/plain with RS-terminated messages
      send(res, 200, out, "text/plain");
    } else {
      // Empty poll timeout — 200 with empty body (BestHTTP treats as no messages)
      logReq(method, pathname + (id ? `?id=${id}` : ""), 200, "poll empty");
      send(res, 200, "", "text/plain");
    }
    return true;
  }

  // POST — handshake or client messages
  if (method === "POST" || method === "PUT") {
    let conn = hubConnections.get(id);
    if (!conn) {
      conn = {
        id: id || "anon",
        created: Date.now(),
        handshakeDone: false,
        messages: [],
      };
      if (id) hubConnections.set(id, conn);
    }

    let responseBody = "";
    const queueToPoll = (s) => {
      // Some BestHTTP builds read handshake from POST response, others from next poll
      responseBody += s;
      conn.messages.push(s);
    };

    processSignalRMessages(conn, bodyAsString(body || ""), queueToPoll);

    // If body has protocol but process missed it
    if (!conn.handshakeDone && body && bodyAsString(body).includes("protocol")) {
      conn.handshakeDone = true;
      const ack = "{}" + RS;
      responseBody += ack;
      conn.messages.push(ack);
    }

    logReq(
      method,
      pathname + (id ? `?id=${id}` : ""),
      200,
      conn.handshakeDone ? "hub post hs" : "hub post"
    );
    send(res, 200, responseBody || "", "text/plain");
    return true;
  }

  // DELETE — abort connection
  if (method === "DELETE") {
    if (id) hubConnections.delete(id);
    send(res, 200, "");
    return true;
  }

  return false;
}

function applyAccountFields(parsed, platformId = "1", platform = 0) {
  return accounts.upsertFromLogin(parsed || {}, platformId, platform);
}

/** OpenRec-compatible default avatar (March 2018/2019 clients) */
function defaultAvatarObject() {
  try {
    const a = JSON.parse(fs.readFileSync(path.join(DATA, "avatar.json"), "utf8"));
    if (a && a.OutfitSelections) return a;
  } catch {
    /* fall through */
  }
  // Minimal valid keys if file missing (FaceFeatures is a JSON *string*)
  return {
    OutfitSelections:
      "b33dbeee-5bdd-443d-aa6a-761248054e08,,,,1;6d48c545-22bb-46c1-a29d-0a38af387143,,,,2;6d48c545-22bb-46c1-a29d-0a38af387143,,,,3",
    HairColor: "bcec4c9d-6d44-4d5f-a9f3-7a5c0e8f1b2c",
    SkinColor: "5f4b8c2a-1d3e-4f67-8901-abcdef123456",
    FaceFeatures:
      '{"ver":3,"eyeId":"AjGMoJhEcEehacRZjUMuDg","eyePos":{"x":0.0,"y":0.0},"eyeScl":0.0,"mouthId":"FrZBRanXEEK29yKJ4jiMjg","mouthPos":{"x":0.0,"y":0.0},"mouthScl":0.0}',
  };
}

/** OpenRec CreateDefaultSettings() + extra keys for screen-mode boot */
function defaultSettingsList() {
  const pairs = [
    ["MOD_BLOCKED_TIME", "0"],
    ["MOD_BLOCKED_DURATION", "0"],
    ["PlayerSessionCount", "1"],
    ["ShowRoomCenter", "1"],
    ["QualitySettings", "3"],
    ["Recroom.OOBE", "100"],
    ["VoiceFilter", "0"],
    ["VIGNETTED_TELEPORT_ENABLED", "0"],
    ["CONTINUOUS_ROTATION_MODE", "0"],
    ["ROTATION_INCREMENT", "0"],
    ["ROTATE_IN_PLACE_ENABLED", "0"],
    ["TeleportBuffer", "0"],
    ["VoiceChat", "1"],
    ["PersonalBubble", "0"],
    ["ShowNames", "1"],
    ["H.264 plugin", "1"],
    // Help AudioManager / screen mode path
    ["AudioMasterVolume", "1"],
    ["AudioMusicVolume", "0.5"],
    ["AudioSfxVolume", "1"],
    ["AudioVoiceVolume", "1"],
    ["MicrophoneEnabled", "0"],
    ["ScreenModeEnabled", "1"],
    ["PlayerAcceptedCodeOfConduct", "1"],
    ["PlayerAcceptedIsolationWarning", "1"],
  ];
  return pairs.map(([Key, Value]) => ({ Key, Value }));
}

async function handleApi(method, apiPath, body, url) {
  const p = apiPath.replace(/\/+$/, "");
  const lower = p.toLowerCase();

  // Version
  if (lower.startsWith("versioncheck")) {
    return { status: 200, data: { ValidVersion: true } };
  }

  // Config
  if (lower === "config/v2" || lower.startsWith("config/v2?")) {
    return { status: 200, data: configV2() };
  }
  if (lower === "config/v1/amplitude") {
    return { status: 200, data: { AmplitudeKey: "FluxLocal" } };
  }
  if (lower === "gameconfigs/v1/all") {
    // Merge RebornRec configs + Flux overrides
    const keys = {
      UseHeartbeatWebSocket: "0",
      forceRegistration: "0",
      "Screens.ForceVerification": "0",
      "Gift.MaxDaily": "100",
      "Gift.DropChance": "100",
      "Gift.Falloff": "1",
      SkipRegistrationVideo: "1",
      StayInSplashScreen: "0",
      SkipProfileSelection: "0",
      "Voice.ForceMute": "0",
      "Network.DisablePhoton": "0",
      "Door.Quests.Query": "#quest",
      "Door.Quests.Title": "QUESTS",
      "Door.Sports.Query": "#sport",
      "Door.Sports.Title": "SPORTS & REC",
      "Door.Shooters.Query": "#pvp",
      "Door.Shooters.Title": "PVP",
      "Door.Creative.Query": "#puzzle",
      "Door.Creative.Title": "PUZZLE",
      "Door.Featured.Query": "#recroomoriginal",
      "Door.Featured.Title": "Featured",
      splitTestSoftOverrides: "[]",
      splitTestHardOverrides: "[]",
      GASamplingRatio: "0",
    };
    const fromFile = rebornGameConfigs();
    const map = new Map();
    for (const row of fromFile) {
      if (row && row.Key != null) map.set(row.Key, row);
    }
    for (const [Key, Value] of Object.entries(keys)) {
      map.set(Key, { Key, Value, StartTime: null, EndTime: null });
    }
    return { status: 200, data: [...map.values()] };
  }

  // Platform login / accounts
  if (
    lower.includes("platformlogin") ||
    lower.includes("logincached") ||
    lower.includes("loginaccount") ||
    lower.includes("createaccount") ||
    lower.includes("getcachedlogins") ||
    lower.includes("removecachedlogin") ||
    lower.includes("refreshlogin") ||
    lower.includes("registeraccount") ||
    lower.startsWith("accounts/")
  ) {
    const parsed = parseBody(body);
    const platformId = parsePlatformId(body);
    const platform = parsePlatform(body);

    // Empty list → main Login + Sign up buttons (not REGISTRATION-only)
    if (lower.includes("getcachedlogins")) {
      return { status: 200, data: [] };
    }
    if (lower.includes("profiles")) {
      return { status: 200, data: [playerObject(platformId, platform)] };
    }
    if (lower.includes("removecachedlogin") || lower.includes("logout")) {
      return { status: 200, data: {} };
    }

    const acc = applyAccountFields(parsed, platformId, platform);
    console.log(
      `[FluxRecNet] AUTH ${lower} user=${acc.username} id=${acc.playerId} platformId=${platformId}`
    );
    return { status: 200, data: loginCached(platformId, platform) };
  }

  // Players
  // CRITICAL: players/v1/list and search MUST be JSON arrays (DeserializeList).
  if (lower.startsWith("players/") || lower.startsWith("player/")) {
    if (lower.includes("disallowinapppurchases")) {
      return { status: 200, data: false };
    }
    // People page search — always return ARRAY
    if (lower.includes("search")) {
      const m =
        (apiPath || "").match(/[?&]name=([^&]+)/i) ||
        (url || "").match(/[?&]name=([^&]+)/i);
      const q = m ? decodeURIComponent(m[1].replace(/\+/g, " ")) : "";
      const hits = accounts.searchPlayers(q).map((a) => playerObject(a.platformId, a.platform, a));
      return { status: 200, data: hits };
    }
    if (lower.includes("listbyplatformid") || lower.includes("list")) {
      let ids = [];
      try {
        const j = parseBody(body);
        if (Array.isArray(j)) ids = j;
        else if (Array.isArray(j?.PlayerIds)) ids = j.PlayerIds;
        else if (Array.isArray(j?.PlatformIds)) {
          // map platform → accounts
          return {
            status: 200,
            data: accounts.listAll().map((a) => playerObject(a.platformId, a.platform, a)),
          };
        }
      } catch {
        /* ignore */
      }
      if (ids.length) {
        const out = ids
          .map((id) => accounts.findById(id))
          .filter(Boolean)
          .map((a) => playerObject(a.platformId, a.platform, a));
        if (out.length) return { status: 200, data: out };
      }
      // default: all known accounts (people browser) or at least active
      const all = accounts.listAll();
      return {
        status: 200,
        data: (all.length ? all : [accounts.getActive()]).map((a) =>
          playerObject(a.platformId, a.platform, a)
        ),
      };
    }
    if (lower.includes("getorcreate")) {
      return { status: 200, data: playerObject() };
    }
    // /players/v2/{id} style
    const idMatch = lower.match(/players\/v\d+\/(\d+)/);
    if (idMatch) {
      const a = accounts.findById(idMatch[1]);
      if (a) return { status: 200, data: playerObject(a.platformId, a.platform, a) };
    }
    return { status: 200, data: playerObject() };
  }

  // Presence
  if (lower.includes("presence")) {
    if (lower.includes("heartbeat")) {
      // OnPresenceHeartbeatResponse expects HeartbeatResponse { Presence: ... }
      return { status: 200, data: heartbeatResponse() };
    }
    if (lower.includes("list")) {
      // POST body: [playerId,...] → List<PlayerPresence>
      return { status: 200, data: [presenceStatus()] };
    }
    // setplayertype / setplayerstatusvisibility / playerDisconnected
    return { status: 200, data: [] };
  }

  // Avatar — OpenRec-compatible default (OutfitSelections + FaceFeatures + colors)
  if (lower.startsWith("avatar/") || lower === "avatar/v2" || lower.startsWith("avatar/v2") || lower.startsWith("avatar/v3")) {
    // Owned closet items — full RebornRec catalog (~1000 shirts/hats/etc.)
    if (lower.includes("/items") || lower.endsWith("items")) {
      return { status: 200, data: getAvatarItems() };
    }
    if (lower.includes("gifts")) {
      // Gift inventory empty is fine; items are already unlocked via /items
      return { status: 200, data: [] };
    }
    if (lower.includes("saved")) {
      // Saved outfits list
      try {
        const a = defaultAvatarObject();
        return {
          status: 200,
          data: [
            {
              Avatar: a,
              AvatarName: "Flux Outfit",
              SlotIndex: 0,
            },
          ],
        };
      } catch {
        return { status: 200, data: [] };
      }
    }
    const defaultAvatar = defaultAvatarObject();
    if (method === "POST" || lower.includes("set")) {
      let saved = defaultAvatar;
      try {
        const j = parseBody(body);
        saved = {
          OutfitSelections:
            j.OutfitSelections ?? j.outfitSelections ?? defaultAvatar.OutfitSelections,
          HairColor: j.HairColor ?? j.hairColor ?? defaultAvatar.HairColor,
          SkinColor: j.SkinColor ?? j.skinColor ?? defaultAvatar.SkinColor,
          FaceFeatures: j.FaceFeatures ?? j.faceFeatures ?? defaultAvatar.FaceFeatures,
        };
        fs.writeFileSync(path.join(DATA, "avatar.json"), JSON.stringify(saved));
      } catch {
        /* ignore */
      }
      return { status: 200, data: saved };
    }
    try {
      const a = JSON.parse(fs.readFileSync(path.join(DATA, "avatar.json"), "utf8"));
      return {
        status: 200,
        data: {
          OutfitSelections: a.OutfitSelections ?? defaultAvatar.OutfitSelections,
          HairColor: a.HairColor ?? defaultAvatar.HairColor,
          SkinColor: a.SkinColor ?? defaultAvatar.SkinColor,
          FaceFeatures: a.FaceFeatures ?? defaultAvatar.FaceFeatures,
        },
      };
    } catch {
      return { status: 200, data: defaultAvatar };
    }
  }

  // Settings — List<{Key,Value}> (OpenRec CreateDefaultSettings)
  if (lower.startsWith("settings/") || lower.startsWith("settings?")) {
    if (method === "POST" || lower.includes("set") || lower.includes("store")) {
      try {
        // body is a single Setting object to upsert
        const j = parseBody(body);
        let arr = [];
        try {
          arr = JSON.parse(fs.readFileSync(path.join(DATA, "settings.json"), "utf8"));
          if (!Array.isArray(arr)) arr = defaultSettingsList();
        } catch {
          arr = defaultSettingsList();
        }
        if (j && j.Key) {
          const idx = arr.findIndex((s) => s.Key === j.Key);
          if (idx >= 0) arr[idx].Value = j.Value;
          else arr.push({ Key: j.Key, Value: String(j.Value ?? "") });
        }
        fs.writeFileSync(path.join(DATA, "settings.json"), JSON.stringify(arr));
        return { status: 200, data: arr };
      } catch {
        return { status: 200, data: defaultSettingsList() };
      }
    }
    try {
      const raw = JSON.parse(fs.readFileSync(path.join(DATA, "settings.json"), "utf8"));
      return {
        status: 200,
        data: Array.isArray(raw) && raw.length ? raw : defaultSettingsList(),
      };
    } catch {
      return { status: 200, data: defaultSettingsList() };
    }
  }

  // Player events — exact OpenRec shape (not [] and not {})
  // {"Created":[],"Responses":[]}
  if (lower.includes("playerevents")) {
    return { status: 200, data: { Created: [], Responses: [] } };
  }

  // Community board (Announcement shape) vs featured room group (FeaturedRooms)
  if (lower.includes("communityboard")) {
    return { status: 200, data: communityBoardPayload() };
  }
  if (lower.includes("featuredroomgroup")) {
    return { status: 200, data: featuredRoomGroupPayload() };
  }

  // Loading tips — list of LoadingScreenTip
  if (lower.includes("loadingscreentip")) {
    return { status: 200, data: loadingScreenTipPayload() };
  }

  // quickPlay getandclear — nullable object, NOT []
  if (lower.includes("quickplay")) {
    return { status: 200, data: null };
  }

  // Named images — array of {FriendlyImageName, ImageName, StartTime, EndTime}
  if (lower.includes("images/v2/named") || lower.includes("images/v1/named")) {
    return {
      status: 200,
      data: [
        {
          FriendlyImageName: "DormRoomBucket",
          ImageName: "DormRoomBucket",
          StartTime: "2018-01-01T00:00:00",
          EndTime: "2030-01-01T00:00:00",
        },
      ],
    };
  }

  // Checklist — OpenRec ChecklistV1Current shape
  if (lower.includes("checklist")) {
    return {
      status: 200,
      data: [
        { Order: 0, Objective: 3000, Count: 3, CreditAmount: 100 },
        { Order: 1, Objective: 3001, Count: 3, CreditAmount: 100 },
        { Order: 2, Objective: 3002, Count: 3, CreditAmount: 100 },
      ],
    };
  }

  // Moderation — not banned
  if (lower.includes("moderationblockdetails") || lower.includes("playerreporting")) {
    return {
      status: 200,
      data: {
        ReportCategory: 0,
        Duration: 0,
        GameSessionId: 0,
        Message: "",
      },
    };
  }

  // Relationships / messages / chat / notifications list APIs
  if (
    lower.includes("relationship") ||
    lower.includes("messages") ||
    lower.includes("notification") ||
    lower.includes("chat") ||
    lower.includes("bulkignore")
  ) {
    return { status: 200, data: [] };
  }

  // Equipment / consumables — full unlock lists (RebornRec data)
  if (lower.includes("equipment")) {
    return { status: 200, data: getEquipmentUnlocked() };
  }
  if (lower.includes("consumable")) {
    return { status: 200, data: getConsumablesUnlocked() };
  }

  // Shop / storefronts — real AvatarItemDesc shirts/hats/etc.
  if (lower.includes("storefront") || lower.includes("giftdrop") || lower.includes("objectives")) {
    if (lower.includes("balance")) {
      return { status: 200, data: currencyBalances() };
    }
    if (lower.includes("balanceadd")) {
      return { status: 200, data: currencyBalances() };
    }
    // e.g. storefronts/v3/giftdropstore/300 or storefronts/v2/2 or objectives
    const m =
      lower.match(/giftdropstore\/(\d+)/) ||
      lower.match(/storefronts\/v\d+\/(\d+)/) ||
      lower.match(/\/(\d+)$/);
    const type = m ? Number(m[1]) : 2;
    return { status: 200, data: buildStorefrontCatalog(type) };
  }

  // IAP gate — must NOT return a Player object
  if (lower.includes("disallowinapppurchases")) {
    return { status: 200, data: false };
  }

  // Events / objectives (OpenRec Objective2018 shape)
  if (lower.includes("objective") && lower.includes("myprogress")) {
    return {
      status: 200,
      data: {
        Objectives: [
          { Index: 2, Group: 0, Progress: 0, VisualProgress: 0, IsCompleted: false, IsRewarded: false },
          { Index: 1, Group: 0, Progress: 0, VisualProgress: 0, IsCompleted: false, IsRewarded: false },
          { Index: 0, Group: 0, Progress: 0, VisualProgress: 0, IsCompleted: false, IsRewarded: false },
        ],
        ObjectiveGroups: [
          { Group: 0, IsCompleted: false, ClearedAt: "2019-01-01T00:00:00Z" },
        ],
      },
    };
  }
  if (lower.includes("challenge") && lower.includes("getcurrent")) {
    return { status: 200, data: { Success: true, Message: "Flux" } };
  }
  if (
    lower.includes("events") ||
    lower.includes("objective") ||
    lower.includes("challenge")
  ) {
    // checklist handled earlier
    if (lower.includes("checklist")) {
      /* fall through handled above */
    }
    return { status: 200, data: [] };
  }

  // Rooms browse / search / details
  if (
    lower.includes("rooms") ||
    lower.includes("baserooms") ||
    lower.includes("hot") ||
    lower.includes("featuredroom")
  ) {
    if (lower.includes("filters")) {
      return { status: 200, data: roomFilters() };
    }
    if (lower.includes("featuredroomgroup") || lower.includes("featured")) {
      return {
        status: 200,
        data: {
          Name: "Flux Rec Room Originals",
          FeaturedRooms: listRooms()
            .filter((r) => !r.IsDormRoom)
            .slice(0, 12)
            .map((r) => ({
              RoomName: r.Name,
              RoomId: r.RoomId,
              ImageName: r.ImageName || "DefaultRoomImage.jpg",
            })),
        },
      };
    }
    if (lower.includes("details")) {
      // rooms/v4/details/2 or rooms/v2/details?name=
      const idMatch = lower.match(/details\/(\d+)/);
      if (idMatch) {
        const id = Number(idMatch[1]);
        const found = Object.values(ROOM_CATALOG).find((d) => d.Room.RoomId === id);
        return {
          status: 200,
          data: found
            ? getRoomDetails(found.Room.Name, getProfile().playerId)
            : dormRoomDetails(),
        };
      }
      const qName = (url && String(url).match(/[?&]name=([^&]+)/i)) || null;
      const name = qName ? decodeURIComponent(qName[1]) : "DormRoom";
      return { status: 200, data: getRoomDetails(name, getProfile().playerId) };
    }
    if (lower.includes("baserooms") || lower.includes("myrooms")) {
      return { status: 200, data: listRooms().filter((r) => !r.IsDormRoom) };
    }
    if (lower.includes("hot") || lower.includes("search")) {
      // tags=#recroomoriginal
      const tagsMatch = (apiPath || "").match(/tags=([^&]+)/i);
      const tags = tagsMatch ? tagsMatch[1] : "";
      return { status: 200, data: listHotRooms(tags) };
    }
    if (lower.includes("instancedetails")) {
      return { status: 200, data: [] };
    }
    // default rooms list
    return { status: 200, data: listRooms().filter((r) => !r.IsDormRoom) };
  }

  // Game sessions — join any catalog room by name
  if (
    lower.includes("gamesession") ||
    lower.includes("joinrandom") ||
    lower.includes("joininstance") ||
    lower.includes("joinroom") ||
    lower.includes("joinplayer")
  ) {
    if (lower.includes("reportjoinresult") || lower.includes("setinprogress")) {
      return { status: 200, data: {} };
    }

    if (lower.includes("joinroom") || lower.includes("joinplayer")) {
      return { status: 200, data: joinRoomResult(body) };
    }

    const j = parseBody(body || "{}");
    const activity =
      j.ActivityLevelIds?.[0] ||
      j.ActivityLevelId ||
      j.RoomName ||
      "DormRoom";
    const { session: gs, roomDetails } = gameSession({
      RoomName: activity,
      Private: !!j.Private,
    });
    return {
      status: 200,
      data: { Result: 0, GameSession: gs, RoomDetails: roomDetails },
    };
  }

  // Images API
  if (lower.includes("images/") || lower.includes("image/")) {
    // Slideshow JSON
    if (lower.includes("slideshow")) {
      const kind = lower.includes("rc") || lower.includes("reccenter") ? "rc" : "dorm";
      return { status: 200, data: slideshowPayload(kind) };
    }
    // Profile upload POST /api/images/v4/profile (raw image or multipart)
    // → game profile pic always; Flux avatar only if launcher-config sync enabled
    if (method === "POST" && lower.includes("profile")) {
      const active = accounts.getActive();
      const buf = Buffer.isBuffer(body)
        ? body
        : Buffer.from(bodyAsString(body || ""), "binary");
      const imageName = saveProfileUpload(active.playerId, active.username, buf);
      if (imageName) {
        accounts.setProfileImageName(active.playerId, imageName);
      }
      // Share pipeline: treat as private Flux draft photo
      if (buf && buf.length > 100) {
        try {
          let syncFlux = false;
          try {
            const lc = JSON.parse(
              fs.readFileSync(
                path.join(__dirname, "..", "launcher-config.json"),
                "utf8"
              )
            );
            syncFlux = !!lc.syncProfileToFlux;
          } catch {
            /* ignore */
          }
          await fluxFb.sharePhotoToFlux(buf, {
            caption: "Profile photo from Rec Room",
          });
          if (syncFlux) {
            await fluxFb.syncProfilePicToFlux(buf, true);
          }
        } catch {
          /* ignore bridge errors */
        }
      }
      return {
        status: 200,
        data: {
          Success: true,
          ImageName: imageName || active.profileImageName || active.username,
        },
      };
    }

    // Saved screenshots / room photos — route "share to RecNet" → Flux private
    if (
      method === "POST" &&
      (lower.includes("images/v") || lower.includes("savedimages") || lower.includes("share"))
    ) {
      const buf = Buffer.isBuffer(body)
        ? body
        : Buffer.from(bodyAsString(body || ""), "binary");
      if (buf && buf.length > 200 && (buf[0] === 0x89 || buf[0] === 0xff)) {
        try {
          const r = await fluxFb.sharePhotoToFlux(buf, {
            caption: "Shared from Rec Room (private until you publish in Flux)",
          });
          return {
            status: 200,
            data: {
              Success: true,
              ImageName: r.mediaUrl || r.draftId || "flux-share",
              FluxPrivate: true,
            },
          };
        } catch {
          /* fall through */
        }
      }
    }
    // Named image binary
    const nameMatch = (apiPath || "").match(/images\/v\d+\/([^/?]+)/i);
    const imgName = nameMatch ? decodeURIComponent(nameMatch[1]) : "default";
    const { buf, type } = getNamedImage(imgName);
    return { status: 200, data: buf, contentType: type || "image/png" };
  }

  if (lower.includes("sanitize") || lower.includes("ispure")) {
    return { status: 200, data: { IsPure: true } };
  }

  if (lower.includes("charades")) {
    return { status: 200, data: [{ Word: "flux", Difficulty: 1 }] };
  }

  // Default empty success — prefer {} for unknown object endpoints that 2019 often expects
  if (method === "POST" || method === "PUT") {
    return { status: 200, data: {} };
  }
  // GET defaults to [] for list-style endpoints
  return { status: 200, data: [] };
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === "OPTIONS") {
      send(res, 204, "");
      return;
    }

    const host = req.headers.host || `${HOST}:${PORT}`;
    const u = new URL(req.url || "/", `http://${host}`);
    const pathname = u.pathname;

    // Health
    if (pathname === "/flux/health") {
      const fx = fluxFb.getActiveFluxSession();
      send(res, 200, {
        ok: true,
        service: "FluxRecNet",
        port: PORT,
        player: getProfile().username,
        hubConnections: hubConnections.size,
        fluxFirebase: fluxFb.firebaseConfigured(),
        fluxUser: fx ? { email: fx.email, username: fx.username, uid: fx.uid } : null,
      });
      return;
    }

    // Flux account login (same email/password as website — never grants admin)
    if (pathname === "/flux/login" && (req.method === "POST" || req.method === "PUT")) {
      const raw = await readBody(req);
      const j = parseBody(raw);
      const email = j.email || j.Email || "";
      const password = j.password || j.Password || "";
      const result = await fluxFb.fluxSignIn(email, password);
      if (!result.ok) {
        send(res, 401, { ok: false, error: result.error });
        return;
      }
      // Map into local RecNet player (non-admin)
      accounts.upsertFromLogin(
        {
          Username: result.username,
          DisplayName: result.displayName,
          Email: result.email,
        },
        "1",
        0
      );
      logReq(req.method, pathname, 200, "flux-login " + result.username);
      send(res, 200, {
        ok: true,
        uid: result.uid,
        username: result.username,
        displayName: result.displayName,
        email: result.email,
        admin: false,
      });
      return;
    }

    // Share photo → Flux private draft (replaces public RecNet feed)
    if (pathname === "/flux/share" && req.method === "POST") {
      const raw = await readBody(req);
      const j = parseBody(raw);
      let buf = Buffer.isBuffer(raw) ? raw : null;
      if (j.imageBase64) {
        buf = Buffer.from(String(j.imageBase64).replace(/^data:image\/\w+;base64,/, ""), "base64");
      }
      if (!buf || buf.length < 50) {
        send(res, 400, { ok: false, error: "No image" });
        return;
      }
      const result = await fluxFb.sharePhotoToFlux(buf, {
        caption: j.caption || "From Rec Room",
      });
      logReq(req.method, pathname, result.ok ? 200 : 500, "flux-share");
      send(res, result.ok ? 200 : 500, result);
      return;
    }

    // CDN-style images: /ImageName?width=256&cropSquare=1  (room thumbs + profiles)
    if (
      req.method === "GET" &&
      pathname.length > 1 &&
      !pathname.includes("/", 1) &&
      (u.searchParams.has("width") ||
        u.searchParams.has("cropSquare") ||
        u.searchParams.has("crop") ||
        pathname.match(/\.(png|jpg|jpeg)$/i))
    ) {
      const imageName = decodeURIComponent(pathname.slice(1));
      const { buf, type } = getNamedImage(imageName);
      logReq(req.method, req.url, 200, "cdn-img " + imageName.slice(0, 40));
      send(res, 200, buf, type || "image/png");
      return;
    }

    // Name server discovery
    if (
      pathname === "/" ||
      pathname === "/2" ||
      pathname === "/2/" ||
      u.searchParams.get("v") === "2" ||
      pathname.toLowerCase().includes("nameserver")
    ) {
      if (!pathname.includes("/api") && !pathname.toLowerCase().includes("hub")) {
        logReq(req.method, req.url, 200, "NS");
        send(res, 200, nameServerPayload());
        return;
      }
    }

    // SignalR Core hub (Notifications) — post-login requires this
    // Paths: /hub/v1, /hub/v1/negotiate, /hub/v1/negotiate/
    if (pathname.toLowerCase().includes("hub/v1") || pathname.toLowerCase().includes("/hub/")) {
      const body = await readBody(req);
      if (body && body.length < 2000) {
        try {
          fs.appendFileSync(LOG, `  body: ${body.slice(0, 400).replace(/\s+/g, " ")}\n`);
        } catch {
          /* ignore */
        }
      }
      const handled = await handleHubHttp(req.method || "GET", pathname, u, body, res);
      if (handled) return;
    }

    const body = await readBody(req);
    if (
      (req.method === "POST" || req.method === "PUT") &&
      body &&
      body.length < 2000 &&
      body.length > 0 &&
      body[0] !== 0x89 &&
      !(body[0] === 0xff && body[1] === 0xd8)
    ) {
      try {
        fs.appendFileSync(
          LOG,
          `  body: ${bodyAsString(body).slice(0, 400).replace(/\s+/g, " ")}\n`
        );
      } catch {
        /* ignore */
      }
    }

    const apiPath = stripApi(pathname);
    const result = await handleApi(req.method || "GET", apiPath + u.search, body, req.url);
    logReq(
      req.method,
      req.url,
      result.status,
      typeof result.data === "string"
        ? result.data.slice(0, 80)
        : Buffer.isBuffer(result.data)
          ? "[bin]"
          : toJson(result.data).slice(0, 80)
    );
    send(res, result.status, result.data, result.contentType || "application/json");
  } catch (e) {
    console.error(e);
    send(res, 500, { Error: String(e.message || e) });
  }
});

// WebSocket upgrades for hub/v1
server.on("upgrade", (req, socket, head) => {
  try {
    const host = req.headers.host || `${HOST}:${PORT}`;
    const u = new URL(req.url || "/", `http://${host}`);
    const pathname = u.pathname.toLowerCase();
    if (pathname.includes("hub")) {
      const id =
        u.searchParams.get("id") ||
        u.searchParams.get("connectionId") ||
        u.searchParams.get("connectionToken") ||
        crypto.randomBytes(8).toString("hex");
      handleWsHub(req, socket, head, id);
      return;
    }
    socket.destroy();
  } catch (e) {
    console.error("upgrade error", e);
    try {
      socket.destroy();
    } catch {
      /* ignore */
    }
  }
});

fs.mkdirSync(DATA, { recursive: true });

// Prevent process exit on stray errors
process.on("uncaughtException", (e) => {
  console.error("[FluxRecNet] uncaughtException", e);
});
process.on("unhandledRejection", (e) => {
  console.error("[FluxRecNet] unhandledRejection", e);
});

server.listen(PORT, HOST, () => {
  console.log("");
  console.log("═══════════════════════════════════════════");
  console.log("  Flux RecNet private server");
  console.log(`  Listening  ${BASE}`);
  console.log(`  NameServer ${BASE}/2`);
  console.log(`  Hub        ${BASE}/hub/v1`);
  console.log(`  Player     ${getProfile().displayName} (@${getProfile().username})`);
  console.log("  Built for  Rec Room March 19, 2019");
  console.log("═══════════════════════════════════════════");
  console.log("");
  try {
    fs.writeFileSync(path.join(DATA, "server.pid"), String(process.pid));
  } catch {
    /* ignore */
  }
});

process.on("SIGINT", () => process.exit(0));
process.on("SIGTERM", () => process.exit(0));
