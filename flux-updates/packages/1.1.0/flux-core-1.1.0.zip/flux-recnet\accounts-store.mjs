/**
 * Multi-account store for Flux RecNet (people search + createaccount).
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA = path.join(__dirname, "data");
const FILE = path.join(DATA, "accounts.json");

function ensureDir() {
  if (!fs.existsSync(DATA)) fs.mkdirSync(DATA, { recursive: true });
}

function loadAll() {
  ensureDir();
  try {
    const j = JSON.parse(fs.readFileSync(FILE, "utf8"));
    if (Array.isArray(j.accounts)) return j;
  } catch {
    /* seed */
  }
  // Migrate single profile.json if present
  let seed = {
    playerId: 100001,
    username: "FluxPlayer",
    displayName: "Flux Player",
    level: 50,
    xp: 99999,
    token: "flux-local-token",
    platformId: "1",
    platform: 0,
    bio: "Playing via Flux RecNet",
    profileImageName: "FluxPlayer",
  };
  try {
    const p = JSON.parse(fs.readFileSync(path.join(DATA, "profile.json"), "utf8"));
    seed = {
      ...seed,
      ...p,
      profileImageName: p.profileImageName || p.username || seed.username,
    };
  } catch {
    /* ignore */
  }
  const store = {
    nextId: Math.max(100002, (seed.playerId || 100001) + 1),
    activePlayerId: seed.playerId || 100001,
    accounts: [seed],
  };
  saveAll(store);
  return store;
}

function saveAll(store) {
  ensureDir();
  fs.writeFileSync(FILE, JSON.stringify(store, null, 2));
  // Keep legacy profile.json in sync with active account
  try {
    const active = store.accounts.find((a) => a.playerId === store.activePlayerId);
    if (active) {
      fs.writeFileSync(
        path.join(DATA, "profile.json"),
        JSON.stringify(
          {
            playerId: active.playerId,
            username: active.username,
            displayName: active.displayName,
            level: active.level,
            xp: active.xp,
            token: active.token,
          },
          null,
          2
        )
      );
    }
  } catch {
    /* ignore */
  }
}

let store = loadAll();

/** Re-read disk if another process/seeder updated accounts.json */
function refreshIfNeeded() {
  try {
    const st = fs.statSync(FILE);
    if (!store._mtime || st.mtimeMs > store._mtime) {
      store = loadAll();
      store._mtime = st.mtimeMs;
    }
  } catch {
    /* ignore */
  }
}

export function getStore() {
  refreshIfNeeded();
  return store;
}

export function getActive() {
  refreshIfNeeded();
  return (
    store.accounts.find((a) => a.playerId === store.activePlayerId) ||
    store.accounts[0]
  );
}

export function setActive(playerId) {
  const a = store.accounts.find((x) => x.playerId === playerId);
  if (a) {
    store.activePlayerId = playerId;
    saveAll(store);
  }
  return a;
}

export function findByUsername(name) {
  const n = String(name || "").toLowerCase();
  return store.accounts.find((a) => a.username.toLowerCase() === n);
}

export function findById(id) {
  return store.accounts.find((a) => a.playerId === Number(id));
}

export function searchPlayers(query) {
  refreshIfNeeded();
  const q = String(query || "").toLowerCase().trim();
  if (!q) return store.accounts.slice(0, 50);
  return store.accounts.filter(
    (a) =>
      a.username.toLowerCase().includes(q) ||
      String(a.displayName || "")
        .toLowerCase()
        .includes(q)
  );
}

export function listAll() {
  refreshIfNeeded();
  return store.accounts.slice();
}

/**
 * Create or update account from login/create payload.
 * New usernames get new playerIds; same username updates.
 */
export function upsertFromLogin(parsed, platformId = "1", platform = 0) {
  const rawUser = String(parsed.Username || parsed.username || "").trim();
  const username =
    rawUser.replace(/[^a-zA-Z0-9_]/g, "").slice(0, 32) ||
    getActive()?.username ||
    "FluxPlayer";
  const displayName = String(
    parsed.DisplayName || parsed.displayName || username
  ).slice(0, 32);

  let acc = findByUsername(username);
  if (!acc) {
    acc = {
      playerId: store.nextId++,
      username,
      displayName,
      level: 50,
      xp: 99999,
      token: "flux-token-" + store.nextId.toString(36),
      platformId: String(platformId),
      platform: Number(platform) || 0,
      bio: "Flux RecNet player",
      profileImageName: username,
      email: parsed.Email || parsed.email || `${username}@flux.local`,
      createdAt: new Date().toISOString(),
    };
    store.accounts.push(acc);
  } else {
    acc.displayName = displayName;
    acc.platformId = String(platformId || acc.platformId);
    acc.platform = Number(platform) || acc.platform || 0;
    if (parsed.Email || parsed.email) acc.email = String(parsed.Email || parsed.email);
  }
  store.activePlayerId = acc.playerId;
  saveAll(store);
  return acc;
}

export function setProfileImageName(playerId, imageName) {
  const a = findById(playerId);
  if (!a) return null;
  a.profileImageName = imageName;
  saveAll(store);
  return a;
}

export function playerObjectFrom(acc, platformId, platform) {
  const a = acc || getActive();
  const pid = platformId != null ? String(platformId) : String(a.platformId || "1");
  const plat = platform != null ? Number(platform) : Number(a.platform || 0);
  return {
    Id: a.playerId,
    Username: a.username,
    DisplayName: a.displayName,
    XP: a.xp ?? 99999,
    Level: a.level ?? 50,
    RegistrationStatus: 2,
    Developer: true,
    CanReceiveInvites: true,
    ProfileImageName: a.profileImageName || a.username,
    JuniorProfile: false,
    ForceJuniorImages: false,
    PendingJunior: false,
    HasBirthday: true,
    AvoidJuniors: true,
    Bio: a.bio || "Playing via Flux RecNet",
    HasEmail: true,
    Verified: true,
    Email: a.email || `${a.username}@flux.local`,
    Birthday: "2000-01-01",
    PlayerReputation: {
      Noteriety: 0,
      Notoriety: 0,
      CheerCredit: 20,
      CheerGeneral: 10,
      CheerHelpful: 10,
      CheerGreatHost: 10,
      CheerSportsman: 10,
      CheerCreative: 10,
      SubscriberCount: 0,
      SubscribedCount: 0,
      SelectedCheer: 0,
    },
    PlatformIds: [{ Platform: plat, PlatformId: pid }],
  };
}
