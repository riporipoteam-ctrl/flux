/**
 * Loads RebornRec-compatible catalogs (avatar items, equipment, consumables)
 * and builds storefront payloads with real AvatarItemDesc GUIDs.
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REBORN = path.join(__dirname, "data", "reborn");

function readJson(name, fallback) {
  try {
    return JSON.parse(fs.readFileSync(path.join(REBORN, name), "utf8"));
  } catch {
    return fallback;
  }
}

let _avatarItems = null;
let _equipment = null;
let _consumables = null;
let _storeCache = new Map();

export function getAvatarItems() {
  if (!_avatarItems) {
    const raw = readJson("avataritems.txt", []);
    // Deduplicate by AvatarItemDesc, keep first FriendlyName
    const seen = new Set();
    _avatarItems = [];
    for (const it of raw) {
      const desc = it.AvatarItemDesc || it.avatarItemDesc;
      if (!desc || seen.has(desc)) continue;
      seen.add(desc);
      _avatarItems.push({
        AvatarItemDesc: desc,
        FriendlyName: it.FriendlyName || it.friendlyName || "Item",
      });
    }
  }
  return _avatarItems;
}

export function getEquipmentUnlocked() {
  if (!_equipment) {
    const raw = readJson("equipment.txt", []);
    _equipment = raw.map((e) => ({
      PrefabName: e.PrefabName || e.prefabName || "",
      ModificationGuid: e.ModificationGuid || e.modificationGuid || "",
      Favorited: !!e.Favorited,
    }));
  }
  return _equipment;
}

export function getConsumablesUnlocked() {
  if (!_consumables) {
    const raw = readJson("consumables.txt", []);
    _consumables = raw.map((c, i) => ({
      Id: c.Id ?? i + 1,
      ConsumableItemDesc: c.ConsumableItemDesc || c.consumableItemDesc || "",
      CreatedAt: c.CreatedAt || "2019-01-01T00:00:00Z",
      Count: c.Count ?? 99,
      InitialCount: c.InitialCount ?? c.Count ?? 99,
      ActiveDurationMinutes: c.ActiveDurationMinutes ?? 0,
      UnlockedLevel: c.UnlockedLevel ?? 0,
      IsActive: !!c.IsActive,
      Category: c.Category ?? 4,
    }));
  }
  return _consumables;
}

/** Pick clothing-ish items for the shop (shirts, hats, etc.) */
function shopCandidates() {
  const items = getAvatarItems();
  const prefer =
    /shirt|tee|hoodie|jacket|pants|short|shoe|boot|hat|cap|hair|skirt|dress|sweater|coat|glove|mask|glasses|beard|mustache|bow|tie|scarf|sock|jersey|hoodie|tank|blouse|polo/i;
  const preferred = items.filter((i) => prefer.test(i.FriendlyName));
  const pool = preferred.length >= 40 ? preferred : items;
  // unique friendly names, first color variant
  const byName = new Map();
  for (const it of pool) {
    if (!byName.has(it.FriendlyName)) byName.set(it.FriendlyName, it);
  }
  return [...byName.values()];
}

/**
 * Build a storefront with real AvatarItemDesc gift drops.
 * storefrontType 2 = tokens, 3 = gift drop, 300 = giftdropstore specialty
 */
export function buildStorefrontCatalog(storefrontType = 2) {
  const type = Number(storefrontType) || 2;
  if (_storeCache.has(type)) return _storeCache.get(type);

  const candidates = shopCandidates();
  const limit = type === 300 ? 80 : 60;
  const slice = candidates.slice(0, limit);

  const StoreItems = slice.map((it, idx) => {
    const rarity = idx < 5 ? 50 : idx < 15 ? 20 : 0;
    const price =
      type === 1
        ? Math.max(50, (idx + 1) * 25)
        : Math.max(100, (idx + 1) * 50 + rarity * 10);
    return {
      PurchasableItemId: idx + 1,
      Type: 0,
      IsFeatured: idx < 8,
      Prices: [{ CurrencyType: type === 1 ? 1 : 2, Price: price }],
      GiftDrops: [
        {
          GiftDropId: idx + 1,
          FriendlyName: it.FriendlyName,
          Tooltip: `${it.FriendlyName} (Flux unlocked)`,
          AvatarItemDesc: it.AvatarItemDesc,
          ConsumableItemDesc: "",
          EquipmentPrefabName: "",
          EquipmentModificationGuid: "",
          Rarity: rarity,
          IsQuery: false,
          Unique: false,
          Level: 1,
          Context: 0,
        },
      ],
    };
  });

  // Also inject a few equipment gift stubs from unlocked gear
  const gear = getEquipmentUnlocked().slice(0, 12);
  gear.forEach((g, i) => {
    const id = StoreItems.length + i + 1;
    StoreItems.push({
      PurchasableItemId: id,
      Type: 0,
      IsFeatured: false,
      Prices: [{ CurrencyType: 2, Price: 250 + i * 50 }],
      GiftDrops: [
        {
          GiftDropId: id,
          FriendlyName: (g.PrefabName || "Gear").replace(/[\[\]]/g, ""),
          Tooltip: "Equipment gift",
          AvatarItemDesc: "",
          ConsumableItemDesc: "",
          EquipmentPrefabName: g.PrefabName || "",
          EquipmentModificationGuid: g.ModificationGuid || "",
          Rarity: 10,
          IsQuery: false,
          Unique: false,
          Level: 1,
          Context: 0,
        },
      ],
    });
  });

  const payload = {
    StorefrontType: type,
    NextUpdate: "2030-01-01T00:00:00Z",
    StoreItems,
  };
  _storeCache.set(type, payload);
  return payload;
}

export function currencyBalances() {
  return [
    { CurrencyType: 2, Balance: 999999, UsedPurchasedCurrency: false },
    { CurrencyType: 1, Balance: 999999, UsedPurchasedCurrency: false },
    { CurrencyType: 3, Balance: 9999, UsedPurchasedCurrency: false },
  ];
}

export function slideshowPayload(kind = "dorm") {
  try {
    const name = kind === "rc" ? "rcslideshow.txt" : "dormslideshow.txt";
    return readJson(name, { Images: [], ValidTill: "2030-01-01T00:00:00Z" });
  } catch {
    return { Images: [], ValidTill: "2030-01-01T00:00:00Z" };
  }
}

export function rebornGameConfigs() {
  return readJson("gameconfigs.txt", []);
}
