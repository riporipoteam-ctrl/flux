/**
 * Profile pics + room thumbnail generation/cache.
 * Official img.rec.net is dead for old IDs — generate solid-color PNGs with
 * distinct hues per name so RRO list isn't blank.
 */
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";
import zlib from "zlib";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA = path.join(__dirname, "data");
const IMG_DIR = path.join(DATA, "images");
const PROFILE_DIR = path.join(DATA, "profiles");

function ensureDirs() {
  for (const d of [DATA, IMG_DIR, PROFILE_DIR]) {
    if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
  }
}

/** CRC32 for PNG chunks */
function crc32(buf) {
  let c = ~0;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) c = c & 1 ? (0xedb88320 ^ (c >>> 1)) : c >>> 1;
  }
  return ~c >>> 0;
}

function chunk(type, data) {
  const typeB = Buffer.from(type, "ascii");
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const crcBuf = Buffer.concat([typeB, data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(crcBuf), 0);
  return Buffer.concat([len, typeB, data, crc]);
}

/**
 * Solid RGB PNG (no deps). Size default 256x256.
 */
export function solidPng(r, g, b, w = 256, h = 256) {
  // IHDR
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 2; // truecolor RGB
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  // raw image: each row filter 0 + RGB pixels
  const rowSize = 1 + w * 3;
  const raw = Buffer.alloc(rowSize * h);
  for (let y = 0; y < h; y++) {
    const row = y * rowSize;
    raw[row] = 0; // filter none
    for (let x = 0; x < w; x++) {
      const p = row + 1 + x * 3;
      // slight gradient so images aren't identical flat blobs
      const f = 0.85 + 0.15 * (x / w);
      raw[p] = Math.min(255, (r * f) | 0);
      raw[p + 1] = Math.min(255, (g * f) | 0);
      raw[p + 2] = Math.min(255, (b * f) | 0);
    }
  }
  const compressed = zlib.deflateSync(raw, { level: 6 });
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  return Buffer.concat([
    sig,
    chunk("IHDR", ihdr),
    chunk("IDAT", compressed),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

function hashColor(name) {
  const h = crypto.createHash("md5").update(String(name || "x")).digest();
  // pleasant mid colors
  return [40 + (h[0] % 180), 40 + (h[1] % 180), 40 + (h[2] % 180)];
}

/** Resolve image bytes for a named image (room thumb or profile) */
export function getNamedImage(imageName) {
  ensureDirs();
  const safe = String(imageName || "default")
    .replace(/[^a-zA-Z0-9._-]/g, "_")
    .slice(0, 120);

  // Profile uploads
  const profilePath = path.join(PROFILE_DIR, safe);
  for (const ext of ["", ".png", ".jpg", ".jpeg"]) {
    const p = profilePath.endsWith(ext) ? profilePath : profilePath + ext;
    if (fs.existsSync(p) && fs.statSync(p).size > 32) {
      return { buf: fs.readFileSync(p), type: "image/png" };
    }
  }

  // Bundled reborn profile image as fallback default
  const rebornProf = path.join(DATA, "reborn", "profileimage.png");
  if (safe === "profileimage" || safe === "DefaultProfile" || safe === "default") {
    if (fs.existsSync(rebornProf)) {
      return { buf: fs.readFileSync(rebornProf), type: "image/png" };
    }
  }

  // Cached generated room/activity image (avoid name.png.png)
  const cacheBase = safe.toLowerCase().endsWith(".png") ? safe.slice(0, -4) : safe;
  const cachePath = path.join(IMG_DIR, cacheBase + ".png");
  if (fs.existsSync(cachePath)) {
    return { buf: fs.readFileSync(cachePath), type: "image/png" };
  }

  const [r, g, b] = hashColor(safe);
  const buf = solidPng(r, g, b, 256, 256);
  try {
    fs.writeFileSync(cachePath, buf);
  } catch {
    /* ignore */
  }
  return { buf, type: "image/png" };
}

/**
 * Save raw profile upload body. Returns image name to set on player.
 */
export function saveProfileUpload(playerId, username, bodyBuf) {
  ensureDirs();
  if (!bodyBuf || bodyBuf.length < 50) return null;

  // Detect image type by magic
  let ext = "png";
  if (bodyBuf[0] === 0xff && bodyBuf[1] === 0xd8) ext = "jpg";
  else if (bodyBuf.slice(0, 4).toString("ascii") === "RIFF") ext = "png";

  // Client often posts multipart — try extract binary after headers
  let data = bodyBuf;
  const asStr = bodyBuf.slice(0, Math.min(800, bodyBuf.length)).toString("binary");
  if (asStr.includes("Content-Type:") && asStr.includes("\r\n\r\n")) {
    const idx = bodyBuf.indexOf(Buffer.from("\r\n\r\n"));
    if (idx > 0) {
      let end = bodyBuf.length;
      const boundaryMatch = asStr.match(/boundary=([^\r\n;]+)/);
      // strip trailing multipart boundary if present
      const start = idx + 4;
      const tail = bodyBuf.slice(start);
      const bIdx = tail.indexOf(Buffer.from("\r\n--"));
      data = bIdx > 0 ? tail.slice(0, bIdx) : tail;
    }
  }

  if (data[0] === 0xff && data[1] === 0xd8) ext = "jpg";
  if (data[0] === 0x89 && data[1] === 0x50) ext = "png";

  const imageName = `profile_${playerId}_${(username || "user").replace(/[^a-zA-Z0-9_]/g, "").slice(0, 24)}`;
  const out = path.join(PROFILE_DIR, imageName + "." + ext);
  // also write without extension for path lookups
  fs.writeFileSync(out, data);
  fs.writeFileSync(path.join(PROFILE_DIR, imageName), data);
  // alias username
  if (username) {
    try {
      fs.writeFileSync(path.join(PROFILE_DIR, username + "." + ext), data);
      fs.writeFileSync(path.join(PROFILE_DIR, username), data);
    } catch {
      /* ignore */
    }
  }
  return imageName;
}

export function defaultTinyPng() {
  return solidPng(60, 100, 180, 64, 64);
}
