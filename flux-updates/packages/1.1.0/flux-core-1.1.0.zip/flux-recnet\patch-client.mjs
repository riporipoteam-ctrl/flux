/**
 * Patch Rec Room March 2019 global-metadata.dat so NameServer points at Flux RecNet.
 * Replaces https://ns.rec.net/?v=2  →  http://127.0.0.1:2059/2  (same length)
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_META = path.resolve(
  __dirname,
  "..",
  "March 19th,2019",
  "Recroom_Release_Data",
  "il2cpp_data",
  "Metadata",
  "global-metadata.dat"
);

const metaPath = process.argv[2] || DEFAULT_META;
const OLD = Buffer.from("https://ns.rec.net/?v=2", "ascii");
const NEW = Buffer.from("http://127.0.0.1:2059/2", "ascii");

if (OLD.length !== NEW.length) {
  console.error("Length mismatch", OLD.length, NEW.length);
  process.exit(1);
}

if (!fs.existsSync(metaPath)) {
  console.error("Metadata not found:", metaPath);
  process.exit(1);
}

const bak = metaPath + ".flux-backup";
if (!fs.existsSync(bak)) {
  fs.copyFileSync(metaPath, bak);
  console.log("Backup →", bak);
}

let buf = fs.readFileSync(metaPath);
let count = 0;
let idx = 0;
while (true) {
  idx = buf.indexOf(OLD, idx);
  if (idx === -1) break;
  NEW.copy(buf, idx);
  count++;
  idx += NEW.length;
}

if (count === 0) {
  // Already patched?
  if (buf.includes(NEW)) {
    console.log("Already patched →", NEW.toString());
    process.exit(0);
  }
  console.error("Target string not found. Is this the March 2019 build?");
  process.exit(1);
}

fs.writeFileSync(metaPath, buf);
console.log(`Patched ${count} occurrence(s) in`);
console.log(" ", metaPath);
console.log(" ", OLD.toString(), "→", NEW.toString());
