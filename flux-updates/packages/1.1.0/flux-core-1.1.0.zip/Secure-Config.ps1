# Encrypt/decrypt Flux password with Windows DPAPI (per-user, no plain text on disk)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Security

function Protect-FluxSecret([string]$plain) {
  if ([string]::IsNullOrEmpty($plain)) { return "" }
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($plain)
  $protected = [System.Security.Cryptography.ProtectedData]::Protect(
    $bytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser
  )
  return [Convert]::ToBase64String($protected)
}

function Unprotect-FluxSecret([string]$b64) {
  if ([string]::IsNullOrEmpty($b64)) { return "" }
  try {
    $bytes = [Convert]::FromBase64String($b64)
    $plain = [System.Security.Cryptography.ProtectedData]::Unprotect(
      $bytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser
    )
    return [System.Text.Encoding]::UTF8.GetString($plain)
  } catch {
    return ""
  }
}

function Get-LauncherConfig($path) {
  if (-not (Test-Path $path)) {
    return [pscustomobject]@{
      buildId              = "2019"
      email                = ""
      passwordEnc          = ""
      syncProfileToFlux    = $false
      updateManifestUrl    = "http://127.0.0.1:3000/flux-updates/manifest.json"
      autoUpdate           = $true
      integrityCheck       = $true
    }
  }
  return (Get-Content $path -Raw | ConvertFrom-Json)
}

function Save-LauncherConfig($path, $cfg) {
  $cfg | ConvertTo-Json -Depth 5 | Set-Content $path -Encoding UTF8
}

# Migrate plain password -> encrypted once
function Migrate-ConfigSecrets($path) {
  $cfg = Get-LauncherConfig $path
  if ($cfg.password -and -not $cfg.passwordEnc) {
    $cfg | Add-Member -NotePropertyName passwordEnc -NotePropertyValue (Protect-FluxSecret $cfg.password) -Force
    $cfg.PSObject.Properties.Remove('password')
    Save-LauncherConfig $path $cfg
  }
  return $cfg
}
