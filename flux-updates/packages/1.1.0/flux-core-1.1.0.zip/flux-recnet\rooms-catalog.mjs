/**
 * Official-ish RRO room catalog for March 2019 Rec Room client.
 * Scene location IDs from OpenRec vault (match client-bundled scenes).
 */

function roomEntry({
  roomId,
  name,
  description,
  imageName = "DefaultRoomImage.jpg",
  sceneLocationId,
  sceneName = "Home",
  isSandbox = false,
  isDorm = false,
  supportsLevelVoting = false,
  tags = ["rro"],
  maxPlayers = 20,
  extraScenes = [],
}) {
  const scenes = [
    {
      RoomSceneId: 1,
      RoomId: roomId,
      RoomSceneLocationId: sceneLocationId,
      Name: sceneName,
      IsSandbox: isSandbox,
      DataBlobName: "",
      MaxPlayers: maxPlayers,
      CanMatchmakeInto: true,
      DataModifiedAt: "2019-01-01T00:00:00Z",
      ReplicationId: name,
      SupportsJoinInProgress: true,
      ReleaseStatus: 2,
      UseAgeBasedMatchmaking: false,
      UseLevelBasedMatchmaking: false,
      UseRecRoyaleMatchmaking: false,
    },
    ...extraScenes.map((s, idx) => ({
      RoomSceneId: idx + 2,
      RoomId: s.roomId ?? roomId,
      RoomSceneLocationId: s.sceneLocationId,
      Name: s.sceneName,
      IsSandbox: !!s.isSandbox,
      DataBlobName: "",
      MaxPlayers: maxPlayers,
      CanMatchmakeInto: true,
      DataModifiedAt: "2019-01-01T00:00:00Z",
      ReplicationId: name,
      SupportsJoinInProgress: true,
      ReleaseStatus: 2,
      UseAgeBasedMatchmaking: false,
      UseLevelBasedMatchmaking: false,
      UseRecRoyaleMatchmaking: false,
    })),
  ];

  return {
    Room: {
      RoomId: roomId,
      Name: name,
      Description: description,
      ImageName: imageName,
      CreatorPlayerId: 1,
      State: 0,
      Accessibility: 1,
      SupportsLevelVoting: supportsLevelVoting,
      IsAGRoom: true,
      IsDormRoom: isDorm,
      CloningAllowed: false,
      SupportsScreens: true,
      SupportsWalkVR: true,
      SupportsTeleportVR: true,
      AllowsJuniors: true,
      DisableMicAutoMute: false,
      DisableRoomComments: false,
      EncryptVoiceChat: false,
      HasDefaultImage: true,
      MaxPlayers: maxPlayers,
      MaxPlayerCalculationMode: 0,
      MinLevel: 0,
      Version: 0,
      WarningMask: 0,
      CustomWarning: null,
      IsRRO: true,
      SupportsVRLow: true,
      SupportsMobile: true,
      SupportsQuest2: true,
      SupportsJuniors: true,
      ReleaseStatus: 2,
      ReplicationId: name,
      CreatedAt: "2019-01-01T00:00:00Z",
    },
    Scenes: scenes,
    CoOwners: [],
    InvitedCoOwners: [],
    Hosts: [],
    InvitedHosts: [],
    CoOwnerIds: [],
    InvitedCoOwnerIds: [],
    HostIds: [],
    InvitedHostIds: [],
    CheerCount: 100,
    FavoriteCount: 50,
    VisitCount: 1000,
    VisitorCount: 1000,
    Tags: tags.map((Tag) => ({ Tag, Type: 2 })),
  };
}

/** Full RoomDetails by canonical name (case-sensitive OpenRec names) */
export const ROOM_CATALOG = {
  DormRoom: roomEntry({
    roomId: 1,
    name: "DormRoom",
    description: "Your private dorm room.",
    sceneLocationId: "76d98498-60a1-430c-ab76-b54a29b7a163",
    sceneName: "dormroom2",
    isDorm: true,
    tags: ["rro", "dorm"],
  }),
  RecCenter: roomEntry({
    roomId: 2,
    name: "RecCenter",
    description: "A social hub to meet and mingle with friends new and old.",
    imageName: "22eefa3219f046fd9e2090814650ede3",
    sceneLocationId: "cbad71af-0831-44d8-b8ef-69edafa841f6",
    sceneName: "reccenter",
    tags: ["rro", "recroomoriginal", "social"],
  }),
  "3DCharades": roomEntry({
    roomId: 3,
    name: "3DCharades",
    description: "Take turns drawing, acting, and guessing funny phrases!",
    imageName: "a446d5808ed14401a27f53e631c31b93.png",
    sceneLocationId: "4078dfed-24bb-4db7-863f-578ba48d726b",
    sceneName: "charades",
    tags: ["rro", "recroomoriginal", "social"],
  }),
  DiscGolfLake: roomEntry({
    roomId: 4,
    name: "DiscGolfLake",
    description: "Throw your disc into the goal. Sounds easy, right?",
    imageName: "52cf6c3271894ecd95fb0c9b2d2209a7",
    sceneLocationId: "f6f7256c-e438-4299-b99e-d20bef8cf7e0",
    sceneName: "discgolf_lake",
    tags: ["rro", "recroomoriginal", "sport"],
  }),
  DiscGolfPropulsion: roomEntry({
    roomId: 5,
    name: "DiscGolfPropulsion",
    description: "Throw your disc into the goal on the Propulsion course.",
    imageName: "fc9a1acc47514b64a30d199d5ccdeca9",
    sceneLocationId: "d9378c9f-80bc-46fb-ad1e-1bed8a674f55",
    sceneName: "discgolf_propulsion",
    tags: ["rro", "recroomoriginal", "sport"],
  }),
  Dodgeball: roomEntry({
    roomId: 6,
    name: "Dodgeball",
    description: "Throw dodgeballs to knock out your friends!",
    imageName: "6d5c494668784816bbc41d9b870e5003",
    sceneLocationId: "3d474b26-26f7-45e9-9a36-9b02847d5e6f",
    sceneName: "dodgeball",
    tags: ["rro", "recroomoriginal", "sport", "pvp"],
  }),
  Paddleball: roomEntry({
    roomId: 7,
    name: "Paddleball",
    description: "A rally game in a plexiglass tube with a zero-g ball.",
    imageName: "ffdca6ed8bd94631ac15e3e894acb6c6",
    sceneLocationId: "d89f74fa-d51e-477a-a425-025a891dd499",
    sceneName: "paddleball",
    tags: ["rro", "recroomoriginal", "sport"],
  }),
  Paintball: roomEntry({
    roomId: 8,
    name: "Paintball",
    description: "Red and Blue teams splat each other in CTF and team battle.",
    imageName: "93a53ced93a04f658795a87f4a4aab85",
    sceneLocationId: "e122fe98-e7db-49e8-a1b1-105424b6e1f0",
    sceneName: "River",
    supportsLevelVoting: true,
    tags: ["rro", "recroomoriginal", "pvp"],
    extraScenes: [
      {
        roomId: 9,
        sceneLocationId: "a785267d-c579-42ea-be43-fec1992d1ca7",
        sceneName: "Homestead",
      },
      {
        roomId: 10,
        sceneLocationId: "380d18b5-de9c-49f3-80f7-f4a95c1de161",
        sceneName: "Clearcut",
      },
    ],
  }),
  GoldenTrophy: roomEntry({
    roomId: 13,
    name: "GoldenTrophy",
    description: "Quest to recover Coach's Golden Trophy from the goblin king!",
    imageName: "38e9d0d4eff94556a0b106508249dcf9",
    sceneLocationId: "91e16e35-f48f-4700-ab8a-a1b79e50e51b",
    sceneName: "Home",
    tags: ["rro", "recroomoriginal", "quest"],
  }),
  Soccer: roomEntry({
    roomId: 17,
    name: "Soccer",
    description: "Teams of three slam into an oversized soccer ball. Goal!",
    imageName: "51c6f5ac5e6f4777b573e7e43f8a85ea",
    sceneLocationId: "6d5eea4b-f069-4ed0-9916-0e2f07df0d03",
    sceneName: "Home",
    tags: ["rro", "recroomoriginal", "sport", "pvp"],
  }),
  LaserTag: roomEntry({
    roomId: 18,
    name: "LaserTag",
    description: "Teams battle each other and waves of robots.",
    imageName: "c5a72193d6904811b2d0195a6deb3125",
    sceneLocationId: "239e676c-f12f-489f-bf3a-d4c383d692c3",
    sceneName: "Hangar",
    tags: ["rro", "recroomoriginal", "pvp"],
    extraScenes: [
      {
        roomId: 19,
        sceneLocationId: "9d6456ce-6264-48b4-808d-2d96b3d91038",
        sceneName: "CyberJunkCity",
      },
    ],
  }),
  Hangar: roomEntry({
    roomId: 18,
    name: "Hangar",
    description: "Teams battle each other and waves of robots.",
    imageName: "ActivityLaserTag.png",
    sceneLocationId: "239e676c-f12f-489f-bf3a-d4c383d692c3",
    sceneName: "Hangar",
    tags: ["rro", "recroomoriginal", "pvp"],
  }),
  Lounge: roomEntry({
    roomId: 22,
    name: "Lounge",
    description: "A low-key lounge to chill with friends. Great for parties!",
    imageName: "ActivityLounge.png",
    sceneLocationId: "a067557f-ca32-43e6-b6e5-daaec60b4f5a",
    sceneName: "Home",
    isSandbox: true,
    tags: ["rro", "recroomoriginal", "social", "community"],
  }),
  PerformanceHall: roomEntry({
    roomId: 23,
    name: "PerformanceHall",
    description: "A theater for plays, music, comedy and performances.",
    sceneLocationId: "9932f88f-3929-43a0-a012-a40b5128e346",
    sceneName: "Home",
    isSandbox: true,
    tags: ["rro", "recroomoriginal", "social", "community"],
  }),
  MakerRoom: roomEntry({
    roomId: 24,
    name: "MakerRoom",
    description: "A blank canvas. Make it into whatever you like!",
    sceneLocationId: "a75f7547-79eb-47c6-8986-6767abcb4f92",
    sceneName: "Home",
    isSandbox: true,
    tags: ["rro", "recroomoriginal", "creative", "community"],
  }),
  Park: roomEntry({
    roomId: 25,
    name: "Park",
    description: "A sprawling park with amphitheater, play fields, and a cave.",
    sceneLocationId: "0a864c86-5a71-4e18-8041-8124e4dc9d98",
    sceneName: "Home",
    isSandbox: true,
    tags: ["rro", "recroomoriginal", "social", "community"],
  }),
  Bowling: roomEntry({
    roomId: 28,
    name: "Bowling",
    description: "Knock down pins with your friends!",
    imageName: "4d143a3359e8483e8d48116ab6cacecb",
    sceneLocationId: "ae929543-9a07-41d5-8ee9-dbbee8c36800",
    sceneName: "Home",
    tags: ["rro", "recroomoriginal", "sport"],
  }),
};

/** Aliases for join requests */
const ALIASES = {
  dorm: "DormRoom",
  dormroom: "DormRoom",
  dormroom2: "DormRoom",
  reccenter: "RecCenter",
  "rec center": "RecCenter",
  rec_center: "RecCenter",
  paintball: "Paintball",
  dodgeball: "Dodgeball",
  paddleball: "Paddleball",
  charades: "3DCharades",
  "3dcharades": "3DCharades",
  discgolflake: "DiscGolfLake",
  discgolfpropulsion: "DiscGolfPropulsion",
  goldentrophy: "GoldenTrophy",
  soccer: "Soccer",
  lasertag: "LaserTag",
  hangar: "Hangar",
  lounge: "Lounge",
  performancehall: "PerformanceHall",
  makerroom: "MakerRoom",
  park: "Park",
  bowling: "Bowling",
};

export function resolveRoomName(raw) {
  if (!raw) return "DormRoom";
  const s = String(raw).trim();
  if (ROOM_CATALOG[s]) return s;
  const key = s.toLowerCase().replace(/\s+/g, "");
  if (ALIASES[key]) return ALIASES[key];
  if (ALIASES[s.toLowerCase()]) return ALIASES[s.toLowerCase()];
  // partial match
  for (const name of Object.keys(ROOM_CATALOG)) {
    if (name.toLowerCase() === s.toLowerCase()) return name;
  }
  return s; // unknown — caller may fall back
}

export function getRoomDetails(roomName, playerId = 1) {
  const name = resolveRoomName(roomName);
  const base = ROOM_CATALOG[name] || ROOM_CATALOG.DormRoom;
  // deep clone + stamp player as creator for dorm
  const details = JSON.parse(JSON.stringify(base));
  if (details.Room.IsDormRoom) {
    details.Room.CreatorPlayerId = playerId;
  }
  return details;
}

export function listRooms() {
  return Object.values(ROOM_CATALOG).map((d) => ({
    ...d.Room,
    // ensure bools are real booleans for client
  }));
}

export function listHotRooms(tagFilter = "") {
  const rooms = listRooms().filter((r) => !r.IsDormRoom);
  if (!tagFilter) return rooms;
  const tags = decodeURIComponent(tagFilter)
    .split(/[,\s]+/)
    .map((t) => t.replace(/^#/, "").toLowerCase())
    .filter(Boolean);
  if (!tags.length) return rooms;
  return rooms.filter((r) => {
    // ROOM_CATALOG tags are on full details; re-check catalog
    const det = ROOM_CATALOG[r.Name];
    if (!det) return true;
    const roomTags = (det.Tags || []).map((t) => String(t.Tag).toLowerCase());
    return tags.some((t) => roomTags.includes(t) || t === "recroomoriginal" || t === "community");
  });
}

export function roomFilters() {
  return [
    { Tag: "recroomoriginal", Label: "Rec Room Original", Type: 2 },
    { Tag: "community", Label: "Community", Type: 2 },
    { Tag: "sport", Label: "Sports", Type: 2 },
    { Tag: "pvp", Label: "PVP", Type: 2 },
    { Tag: "quest", Label: "Quests", Type: 2 },
    { Tag: "social", Label: "Social", Type: 2 },
    { Tag: "creative", Label: "Creative", Type: 2 },
  ];
}

/** Clean shop catalog (tokens) — not OpenRec meme storefront */
export function storefrontCatalog(storefrontType = 2) {
  return {
    StorefrontType: Number(storefrontType) || 2,
    NextUpdate: "2030-01-01T00:00:00Z",
    StoreItems: [
      {
        PurchasableItemId: 1,
        Type: 0,
        IsFeatured: true,
        Prices: [{ CurrencyType: 2, Price: 100 }],
        GiftDrops: [
          {
            GiftDropId: 1,
            FriendlyName: "Flux Starter Shirt",
            Tooltip: "A free-style Flux gift (cosmetic stub)",
            AvatarItemDesc: "",
            ConsumableItemDesc: "",
            EquipmentPrefabName: "",
            EquipmentModificationGuid: "",
            Rarity: 0,
            IsQuery: false,
            Unique: false,
            Level: 1,
            Context: 0,
          },
        ],
      },
      {
        PurchasableItemId: 2,
        Type: 0,
        IsFeatured: false,
        Prices: [{ CurrencyType: 2, Price: 500 }],
        GiftDrops: [
          {
            GiftDropId: 2,
            FriendlyName: "Flux Cap",
            Tooltip: "Shop stub item",
            AvatarItemDesc: "",
            ConsumableItemDesc: "",
            EquipmentPrefabName: "",
            EquipmentModificationGuid: "",
            Rarity: 10,
            IsQuery: false,
            Unique: false,
            Level: 1,
            Context: 0,
          },
        ],
      },
    ],
  };
}

/** Currency balances — type 2 = tokens */
export function currencyBalances() {
  return [
    { CurrencyType: 2, Balance: 999999, UsedPurchasedCurrency: false },
    { CurrencyType: 1, Balance: 999999, UsedPurchasedCurrency: false },
    { CurrencyType: 3, Balance: 0, UsedPurchasedCurrency: false },
  ];
}
