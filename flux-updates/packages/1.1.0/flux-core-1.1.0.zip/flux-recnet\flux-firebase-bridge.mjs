/**
 * Bridge RecNet ↔ Firebase (Auth + Firestore + Storage REST).
 * Users sign in with the same email/password as Flux.
 * Never grants admin — only user-scoped writes.
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import crypto from "crypto";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA = path.join(__dirname, "data");
const SESSIONS = path.join(DATA, "flux-sessions.json");

function loadEnvFromFlux() {
  const envPath = path.resolve(__dirname, "..", "..", ".env.local");
  const out = {};
  try {
    const text = fs.readFileSync(envPath, "utf8");
    for (const line of text.split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)$/);
      if (!m) continue;
      let v = m[2].trim();
      if (
        (v.startsWith('"') && v.endsWith('"')) ||
        (v.startsWith("'") && v.endsWith("'"))
      ) {
        v = v.slice(1, -1);
      }
      out[m[1]] = v;
    }
  } catch {
    /* ignore */
  }
  return {
    apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || out.NEXT_PUBLIC_FIREBASE_API_KEY || "",
    projectId:
      process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID ||
      out.NEXT_PUBLIC_FIREBASE_PROJECT_ID ||
      "",
    storageBucket:
      process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET ||
      out.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET ||
      "",
  };
}

const cfg = loadEnvFromFlux();

function loadSessions() {
  try {
    return JSON.parse(fs.readFileSync(SESSIONS, "utf8"));
  } catch {
    return {};
  }
}

function saveSessions(s) {
  if (!fs.existsSync(DATA)) fs.mkdirSync(DATA, { recursive: true });
  fs.writeFileSync(SESSIONS, JSON.stringify(s, null, 2));
}

export function firebaseConfigured() {
  return !!(cfg.apiKey && cfg.projectId);
}

export async function fluxSignIn(email, password) {
  if (!firebaseConfigured()) {
    return { ok: false, error: "Firebase not configured in .env.local" };
  }
  const url = `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${cfg.apiKey}`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      email: String(email).trim(),
      password: String(password),
      returnSecureToken: true,
    }),
  });
  const data = await res.json();
  if (!res.ok) {
    return {
      ok: false,
      error: data?.error?.message || "Login failed",
    };
  }
  // Load username from Firestore users/{uid}
  let username = (data.email || "").split("@")[0];
  let displayName = username;
  let isAdmin = false;
  try {
    const docUrl = `https://firestore.googleapis.com/v1/projects/${cfg.projectId}/databases/(default)/documents/users/${data.localId}`;
    const dr = await fetch(docUrl, {
      headers: { Authorization: `Bearer ${data.idToken}` },
    });
    if (dr.ok) {
      const doc = await dr.json();
      const f = doc.fields || {};
      if (f.username?.stringValue) username = f.username.stringValue;
      if (f.displayName?.stringValue) displayName = f.displayName.stringValue;
      isAdmin = f.isAdmin?.booleanValue === true;
    }
  } catch {
    /* ignore */
  }

  // Never elevate via game — strip admin for game session identity
  const sessions = loadSessions();
  sessions[data.localId] = {
    uid: data.localId,
    email: data.email,
    idToken: data.idToken,
    refreshToken: data.refreshToken,
    username,
    displayName,
    isAdmin: false, // game never gets admin powers
    fluxIsAdmin: isAdmin, // stored only for logging; not used for grants
    updatedAt: new Date().toISOString(),
  };
  saveSessions(sessions);

  return {
    ok: true,
    uid: data.localId,
    email: data.email,
    username,
    displayName,
    idToken: data.idToken,
  };
}

export function getSession(uid) {
  const s = loadSessions()[uid];
  return s || null;
}

export function getActiveFluxSession() {
  const all = loadSessions();
  const list = Object.values(all).sort((a, b) =>
    (b.updatedAt || "").localeCompare(a.updatedAt || "")
  );
  return list[0] || null;
}

/** Share in-game photo privately to Flux (draft post) */
export async function sharePhotoToFlux(buf, opts = {}) {
  const session = opts.uid ? getSession(opts.uid) : getActiveFluxSession();
  if (!session?.idToken || !session.uid) {
    return { ok: false, error: "Not logged into Flux in launcher" };
  }
  if (!firebaseConfigured() || !cfg.storageBucket) {
    // Local fallback: save file + draft metadata
    const dir = path.join(DATA, "flux-drafts", session.uid);
    fs.mkdirSync(dir, { recursive: true });
    const id = crypto.randomBytes(8).toString("hex");
    const file = path.join(dir, `${id}.png`);
    fs.writeFileSync(file, buf);
    const meta = {
      id,
      uid: session.uid,
      path: file,
      private: true,
      createdAt: new Date().toISOString(),
      caption: opts.caption || "Shared from Rec Room",
    };
    fs.writeFileSync(path.join(dir, `${id}.json`), JSON.stringify(meta, null, 2));
    return { ok: true, local: true, draftId: id, message: "Saved local Flux draft" };
  }

  const objectName = `game-shares/${session.uid}/${Date.now()}_${crypto.randomBytes(4).toString("hex")}.png`;
  const uploadUrl = `https://firebasestorage.googleapis.com/v0/b/${cfg.storageBucket}/o?uploadType=media&name=${encodeURIComponent(objectName)}`;
  const up = await fetch(uploadUrl, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${session.idToken}`,
      "Content-Type": "image/png",
    },
    body: buf,
  });
  if (!up.ok) {
    const t = await up.text();
    return { ok: false, error: `Storage upload failed: ${t.slice(0, 200)}` };
  }
  const upJson = await up.json();
  const token = upJson.downloadTokens;
  const mediaUrl = token
    ? `https://firebasestorage.googleapis.com/v0/b/${cfg.storageBucket}/o/${encodeURIComponent(objectName)}?alt=media&token=${token}`
    : `https://firebasestorage.googleapis.com/v0/b/${cfg.storageBucket}/o/${encodeURIComponent(objectName)}?alt=media`;

  // Private draft post
  const postId = crypto.randomBytes(12).toString("hex");
  const docUrl = `https://firestore.googleapis.com/v1/projects/${cfg.projectId}/databases/(default)/documents/posts?documentId=${postId}`;
  const now = new Date().toISOString();
  const body = {
    fields: {
      authorId: { stringValue: session.uid },
      text: { stringValue: opts.caption || "📸 From Rec Room (private draft)" },
      media: {
        arrayValue: {
          values: [
            {
              mapValue: {
                fields: {
                  type: { stringValue: "image" },
                  url: { stringValue: mediaUrl },
                },
              },
            },
          ],
        },
      },
      type: { stringValue: "post" },
      visibility: { stringValue: "private" },
      isDraft: { booleanValue: true },
      isDeleted: { booleanValue: false },
      source: { stringValue: "recroom-game" },
      likesCount: { integerValue: "0" },
      repliesCount: { integerValue: "0" },
      repostsCount: { integerValue: "0" },
      quotesCount: { integerValue: "0" },
      bookmarksCount: { integerValue: "0" },
      viewsCount: { integerValue: "0" },
      hashtags: { arrayValue: { values: [] } },
      mentions: { arrayValue: { values: [] } },
      createdAt: { timestampValue: now },
      updatedAt: { timestampValue: now },
    },
  };
  const pr = await fetch(docUrl, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${session.idToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  if (!pr.ok) {
    const t = await pr.text();
    return {
      ok: true,
      mediaUrl,
      warn: `Image uploaded but post draft failed: ${t.slice(0, 120)}`,
    };
  }
  return { ok: true, mediaUrl, postId, private: true };
}

/** Optionally update Flux avatar from in-game profile pic */
export async function syncProfilePicToFlux(buf, applyToFlux) {
  if (!applyToFlux) {
    return { ok: true, skipped: true };
  }
  const session = getActiveFluxSession();
  if (!session?.idToken) {
    return { ok: false, error: "Not logged into Flux" };
  }
  // Reuse share upload path then patch user avatarUrl
  const shared = await sharePhotoToFlux(buf, {
    uid: session.uid,
    caption: "Profile photo from Rec Room",
  });
  if (!shared.ok || !shared.mediaUrl) return shared;

  const patchUrl = `https://firestore.googleapis.com/v1/projects/${cfg.projectId}/databases/(default)/documents/users/${session.uid}?updateMask.fieldPaths=avatarUrl&updateMask.fieldPaths=updatedAt`;
  const now = new Date().toISOString();
  const res = await fetch(patchUrl, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${session.idToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      fields: {
        avatarUrl: { stringValue: shared.mediaUrl },
        updatedAt: { timestampValue: now },
      },
    }),
  });
  if (!res.ok) {
    return { ok: false, error: "Failed to update Flux avatar" };
  }
  return { ok: true, avatarUrl: shared.mediaUrl };
}
